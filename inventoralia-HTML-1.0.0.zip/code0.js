gdjs.SplashSceneCode = {};
gdjs.SplashSceneCode.GDtxt_95creditsObjects1= [];
gdjs.SplashSceneCode.GDtxt_95creditsObjects2= [];
gdjs.SplashSceneCode.GDtxt_95creditsObjects3= [];

gdjs.SplashSceneCode.conditionTrue_0 = {val:false};
gdjs.SplashSceneCode.condition0IsTrue_0 = {val:false};
gdjs.SplashSceneCode.condition1IsTrue_0 = {val:false};


gdjs.SplashSceneCode.eventsList0 = function(runtimeScene) {

{



}


};gdjs.SplashSceneCode.eventsList1 = function(runtimeScene) {

{



}


{



}


{



}


{



}


{



}


{



}


{



}


};gdjs.SplashSceneCode.mapOfGDgdjs_46SplashSceneCode_46GDtxt_9595creditsObjects1Objects = Hashtable.newFrom({"txt_credits": gdjs.SplashSceneCode.GDtxt_95creditsObjects1});gdjs.SplashSceneCode.eventsList2 = function(runtimeScene) {

{


{
gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.SplashSceneCode.mapOfGDgdjs_46SplashSceneCode_46GDtxt_9595creditsObjects1Objects, gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2, gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2, "");
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setGradient("LINEAR_VERTICAL", "255;217;153", "219;168;83", "196;138;43", "207;47;66");
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setCharacterSize(24);
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setOutline("0;0;0", 4);
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setScale(1);
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length ;i < len;++i) {
    gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].setPosition((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].getWidth()) / 2),(gdjs.evtTools.window.getGameResolutionHeight(runtimeScene) / 2) - ((gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].getHeight()) / 2));
}
}}

}


};gdjs.SplashSceneCode.eventsList3 = function(runtimeScene) {

{


gdjs.SplashSceneCode.eventsList2(runtimeScene);
}


};gdjs.SplashSceneCode.eventsList4 = function(runtimeScene) {

{


gdjs.SplashSceneCode.condition0IsTrue_0.val = false;
{
gdjs.SplashSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.SplashSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.SplashSceneCode.eventsList3(runtimeScene);} //End of subevents
}

}


};gdjs.SplashSceneCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("txt_credits"), gdjs.SplashSceneCode.GDtxt_95creditsObjects2);

gdjs.SplashSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SplashSceneCode.GDtxt_95creditsObjects2.length;i<l;++i) {
    if ( gdjs.SplashSceneCode.GDtxt_95creditsObjects2[i].getBehavior("Text_AutoTyping").TypingFinished((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        gdjs.SplashSceneCode.condition0IsTrue_0.val = true;
        gdjs.SplashSceneCode.GDtxt_95creditsObjects2[k] = gdjs.SplashSceneCode.GDtxt_95creditsObjects2[i];
        ++k;
    }
}
gdjs.SplashSceneCode.GDtxt_95creditsObjects2.length = k;}if (gdjs.SplashSceneCode.condition0IsTrue_0.val) {
{gdjs.evtsExt__Wait__WaitAction.func(runtimeScene, "start", (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


{


gdjs.SplashSceneCode.condition0IsTrue_0.val = false;
{
gdjs.SplashSceneCode.condition0IsTrue_0.val = gdjs.evtsExt__Wait__WaitCondition.func(runtimeScene, "start", 0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}if (gdjs.SplashSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameScene", true);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("txt_credits"), gdjs.SplashSceneCode.GDtxt_95creditsObjects1);

gdjs.SplashSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length;i<l;++i) {
    if ( !(gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i].getBehavior("Text_AutoTyping").TypingPause((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        gdjs.SplashSceneCode.condition0IsTrue_0.val = true;
        gdjs.SplashSceneCode.GDtxt_95creditsObjects1[k] = gdjs.SplashSceneCode.GDtxt_95creditsObjects1[i];
        ++k;
    }
}
gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length = k;}if (gdjs.SplashSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\07-text-blip.wav", 1, true, 30, 1);
}}

}


};gdjs.SplashSceneCode.eventsList6 = function(runtimeScene) {

{


gdjs.SplashSceneCode.eventsList0(runtimeScene);
}


{


gdjs.SplashSceneCode.eventsList1(runtimeScene);
}


{


gdjs.SplashSceneCode.eventsList4(runtimeScene);
}


{


gdjs.SplashSceneCode.eventsList5(runtimeScene);
}


};

gdjs.SplashSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.SplashSceneCode.GDtxt_95creditsObjects1.length = 0;
gdjs.SplashSceneCode.GDtxt_95creditsObjects2.length = 0;
gdjs.SplashSceneCode.GDtxt_95creditsObjects3.length = 0;

gdjs.SplashSceneCode.eventsList6(runtimeScene);
return;

}

gdjs['SplashSceneCode'] = gdjs.SplashSceneCode;
