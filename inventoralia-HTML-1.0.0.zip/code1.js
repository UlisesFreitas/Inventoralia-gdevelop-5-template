gdjs.GameSceneCode = {};
gdjs.GameSceneCode.forEachIndex2 = 0;

gdjs.GameSceneCode.forEachIndex3 = 0;

gdjs.GameSceneCode.forEachIndex4 = 0;

gdjs.GameSceneCode.forEachIndex5 = 0;

gdjs.GameSceneCode.forEachObjects2 = [];

gdjs.GameSceneCode.forEachObjects3 = [];

gdjs.GameSceneCode.forEachObjects4 = [];

gdjs.GameSceneCode.forEachObjects5 = [];

gdjs.GameSceneCode.forEachTemporary2 = null;

gdjs.GameSceneCode.forEachTemporary3 = null;

gdjs.GameSceneCode.forEachTemporary4 = null;

gdjs.GameSceneCode.forEachTemporary5 = null;

gdjs.GameSceneCode.forEachTotalCount2 = 0;

gdjs.GameSceneCode.forEachTotalCount3 = 0;

gdjs.GameSceneCode.forEachTotalCount4 = 0;

gdjs.GameSceneCode.forEachTotalCount5 = 0;

gdjs.GameSceneCode.repeatCount3 = 0;

gdjs.GameSceneCode.repeatCount4 = 0;

gdjs.GameSceneCode.repeatCount5 = 0;

gdjs.GameSceneCode.repeatCount6 = 0;

gdjs.GameSceneCode.repeatCount7 = 0;

gdjs.GameSceneCode.repeatIndex3 = 0;

gdjs.GameSceneCode.repeatIndex4 = 0;

gdjs.GameSceneCode.repeatIndex5 = 0;

gdjs.GameSceneCode.repeatIndex6 = 0;

gdjs.GameSceneCode.repeatIndex7 = 0;

gdjs.GameSceneCode.GDshop_95slotObjects1= [];
gdjs.GameSceneCode.GDshop_95slotObjects2= [];
gdjs.GameSceneCode.GDshop_95slotObjects3= [];
gdjs.GameSceneCode.GDshop_95slotObjects4= [];
gdjs.GameSceneCode.GDshop_95slotObjects5= [];
gdjs.GameSceneCode.GDshop_95slotObjects6= [];
gdjs.GameSceneCode.GDshop_95slotObjects7= [];
gdjs.GameSceneCode.GDshop_95slotObjects8= [];
gdjs.GameSceneCode.GDinventory_95slotObjects1= [];
gdjs.GameSceneCode.GDinventory_95slotObjects2= [];
gdjs.GameSceneCode.GDinventory_95slotObjects3= [];
gdjs.GameSceneCode.GDinventory_95slotObjects4= [];
gdjs.GameSceneCode.GDinventory_95slotObjects5= [];
gdjs.GameSceneCode.GDinventory_95slotObjects6= [];
gdjs.GameSceneCode.GDinventory_95slotObjects7= [];
gdjs.GameSceneCode.GDinventory_95slotObjects8= [];
gdjs.GameSceneCode.GDinventory_95binObjects1= [];
gdjs.GameSceneCode.GDinventory_95binObjects2= [];
gdjs.GameSceneCode.GDinventory_95binObjects3= [];
gdjs.GameSceneCode.GDinventory_95binObjects4= [];
gdjs.GameSceneCode.GDinventory_95binObjects5= [];
gdjs.GameSceneCode.GDinventory_95binObjects6= [];
gdjs.GameSceneCode.GDinventory_95binObjects7= [];
gdjs.GameSceneCode.GDinventory_95binObjects8= [];
gdjs.GameSceneCode.GDpointer_95dragobjectObjects1= [];
gdjs.GameSceneCode.GDpointer_95dragobjectObjects2= [];
gdjs.GameSceneCode.GDpointer_95dragobjectObjects3= [];
gdjs.GameSceneCode.GDpointer_95dragobjectObjects4= [];
gdjs.GameSceneCode.GDpointer_95dragobjectObjects5= [];
gdjs.GameSceneCode.GDpointer_95dragobjectObjects6= [];
gdjs.GameSceneCode.GDpointer_95dragobjectObjects7= [];
gdjs.GameSceneCode.GDpointer_95dragobjectObjects8= [];
gdjs.GameSceneCode.GDslot_95textObjects1= [];
gdjs.GameSceneCode.GDslot_95textObjects2= [];
gdjs.GameSceneCode.GDslot_95textObjects3= [];
gdjs.GameSceneCode.GDslot_95textObjects4= [];
gdjs.GameSceneCode.GDslot_95textObjects5= [];
gdjs.GameSceneCode.GDslot_95textObjects6= [];
gdjs.GameSceneCode.GDslot_95textObjects7= [];
gdjs.GameSceneCode.GDslot_95textObjects8= [];
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1= [];
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2= [];
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects3= [];
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects4= [];
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects5= [];
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects6= [];
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects7= [];
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects8= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects1= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects3= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects4= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects5= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects6= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects7= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects8= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects1= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects3= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects4= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects5= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects6= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects7= [];
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects8= [];
gdjs.GameSceneCode.GDtxt_95item_95descObjects1= [];
gdjs.GameSceneCode.GDtxt_95item_95descObjects2= [];
gdjs.GameSceneCode.GDtxt_95item_95descObjects3= [];
gdjs.GameSceneCode.GDtxt_95item_95descObjects4= [];
gdjs.GameSceneCode.GDtxt_95item_95descObjects5= [];
gdjs.GameSceneCode.GDtxt_95item_95descObjects6= [];
gdjs.GameSceneCode.GDtxt_95item_95descObjects7= [];
gdjs.GameSceneCode.GDtxt_95item_95descObjects8= [];
gdjs.GameSceneCode.GDtxt_95item_95titleObjects1= [];
gdjs.GameSceneCode.GDtxt_95item_95titleObjects2= [];
gdjs.GameSceneCode.GDtxt_95item_95titleObjects3= [];
gdjs.GameSceneCode.GDtxt_95item_95titleObjects4= [];
gdjs.GameSceneCode.GDtxt_95item_95titleObjects5= [];
gdjs.GameSceneCode.GDtxt_95item_95titleObjects6= [];
gdjs.GameSceneCode.GDtxt_95item_95titleObjects7= [];
gdjs.GameSceneCode.GDtxt_95item_95titleObjects8= [];
gdjs.GameSceneCode.GDtxt_95titleObjects1= [];
gdjs.GameSceneCode.GDtxt_95titleObjects2= [];
gdjs.GameSceneCode.GDtxt_95titleObjects3= [];
gdjs.GameSceneCode.GDtxt_95titleObjects4= [];
gdjs.GameSceneCode.GDtxt_95titleObjects5= [];
gdjs.GameSceneCode.GDtxt_95titleObjects6= [];
gdjs.GameSceneCode.GDtxt_95titleObjects7= [];
gdjs.GameSceneCode.GDtxt_95titleObjects8= [];
gdjs.GameSceneCode.GDinventory_95title2Objects1= [];
gdjs.GameSceneCode.GDinventory_95title2Objects2= [];
gdjs.GameSceneCode.GDinventory_95title2Objects3= [];
gdjs.GameSceneCode.GDinventory_95title2Objects4= [];
gdjs.GameSceneCode.GDinventory_95title2Objects5= [];
gdjs.GameSceneCode.GDinventory_95title2Objects6= [];
gdjs.GameSceneCode.GDinventory_95title2Objects7= [];
gdjs.GameSceneCode.GDinventory_95title2Objects8= [];
gdjs.GameSceneCode.GDinventory_95titleObjects1= [];
gdjs.GameSceneCode.GDinventory_95titleObjects2= [];
gdjs.GameSceneCode.GDinventory_95titleObjects3= [];
gdjs.GameSceneCode.GDinventory_95titleObjects4= [];
gdjs.GameSceneCode.GDinventory_95titleObjects5= [];
gdjs.GameSceneCode.GDinventory_95titleObjects6= [];
gdjs.GameSceneCode.GDinventory_95titleObjects7= [];
gdjs.GameSceneCode.GDinventory_95titleObjects8= [];
gdjs.GameSceneCode.GDtxt_95controlsObjects1= [];
gdjs.GameSceneCode.GDtxt_95controlsObjects2= [];
gdjs.GameSceneCode.GDtxt_95controlsObjects3= [];
gdjs.GameSceneCode.GDtxt_95controlsObjects4= [];
gdjs.GameSceneCode.GDtxt_95controlsObjects5= [];
gdjs.GameSceneCode.GDtxt_95controlsObjects6= [];
gdjs.GameSceneCode.GDtxt_95controlsObjects7= [];
gdjs.GameSceneCode.GDtxt_95controlsObjects8= [];
gdjs.GameSceneCode.GDitem_95cardObjects1= [];
gdjs.GameSceneCode.GDitem_95cardObjects2= [];
gdjs.GameSceneCode.GDitem_95cardObjects3= [];
gdjs.GameSceneCode.GDitem_95cardObjects4= [];
gdjs.GameSceneCode.GDitem_95cardObjects5= [];
gdjs.GameSceneCode.GDitem_95cardObjects6= [];
gdjs.GameSceneCode.GDitem_95cardObjects7= [];
gdjs.GameSceneCode.GDitem_95cardObjects8= [];
gdjs.GameSceneCode.GDitem_95potion_95hpObjects1= [];
gdjs.GameSceneCode.GDitem_95potion_95hpObjects2= [];
gdjs.GameSceneCode.GDitem_95potion_95hpObjects3= [];
gdjs.GameSceneCode.GDitem_95potion_95hpObjects4= [];
gdjs.GameSceneCode.GDitem_95potion_95hpObjects5= [];
gdjs.GameSceneCode.GDitem_95potion_95hpObjects6= [];
gdjs.GameSceneCode.GDitem_95potion_95hpObjects7= [];
gdjs.GameSceneCode.GDitem_95potion_95hpObjects8= [];
gdjs.GameSceneCode.GDitem_95potion_95mpObjects1= [];
gdjs.GameSceneCode.GDitem_95potion_95mpObjects2= [];
gdjs.GameSceneCode.GDitem_95potion_95mpObjects3= [];
gdjs.GameSceneCode.GDitem_95potion_95mpObjects4= [];
gdjs.GameSceneCode.GDitem_95potion_95mpObjects5= [];
gdjs.GameSceneCode.GDitem_95potion_95mpObjects6= [];
gdjs.GameSceneCode.GDitem_95potion_95mpObjects7= [];
gdjs.GameSceneCode.GDitem_95potion_95mpObjects8= [];
gdjs.GameSceneCode.GDitem_95potion_95expObjects1= [];
gdjs.GameSceneCode.GDitem_95potion_95expObjects2= [];
gdjs.GameSceneCode.GDitem_95potion_95expObjects3= [];
gdjs.GameSceneCode.GDitem_95potion_95expObjects4= [];
gdjs.GameSceneCode.GDitem_95potion_95expObjects5= [];
gdjs.GameSceneCode.GDitem_95potion_95expObjects6= [];
gdjs.GameSceneCode.GDitem_95potion_95expObjects7= [];
gdjs.GameSceneCode.GDitem_95potion_95expObjects8= [];
gdjs.GameSceneCode.GDitem_95heartObjects1= [];
gdjs.GameSceneCode.GDitem_95heartObjects2= [];
gdjs.GameSceneCode.GDitem_95heartObjects3= [];
gdjs.GameSceneCode.GDitem_95heartObjects4= [];
gdjs.GameSceneCode.GDitem_95heartObjects5= [];
gdjs.GameSceneCode.GDitem_95heartObjects6= [];
gdjs.GameSceneCode.GDitem_95heartObjects7= [];
gdjs.GameSceneCode.GDitem_95heartObjects8= [];
gdjs.GameSceneCode.GDitem_95chickenObjects1= [];
gdjs.GameSceneCode.GDitem_95chickenObjects2= [];
gdjs.GameSceneCode.GDitem_95chickenObjects3= [];
gdjs.GameSceneCode.GDitem_95chickenObjects4= [];
gdjs.GameSceneCode.GDitem_95chickenObjects5= [];
gdjs.GameSceneCode.GDitem_95chickenObjects6= [];
gdjs.GameSceneCode.GDitem_95chickenObjects7= [];
gdjs.GameSceneCode.GDitem_95chickenObjects8= [];
gdjs.GameSceneCode.GDitem_95book_95mpObjects1= [];
gdjs.GameSceneCode.GDitem_95book_95mpObjects2= [];
gdjs.GameSceneCode.GDitem_95book_95mpObjects3= [];
gdjs.GameSceneCode.GDitem_95book_95mpObjects4= [];
gdjs.GameSceneCode.GDitem_95book_95mpObjects5= [];
gdjs.GameSceneCode.GDitem_95book_95mpObjects6= [];
gdjs.GameSceneCode.GDitem_95book_95mpObjects7= [];
gdjs.GameSceneCode.GDitem_95book_95mpObjects8= [];
gdjs.GameSceneCode.GDitem_95book_95hpObjects1= [];
gdjs.GameSceneCode.GDitem_95book_95hpObjects2= [];
gdjs.GameSceneCode.GDitem_95book_95hpObjects3= [];
gdjs.GameSceneCode.GDitem_95book_95hpObjects4= [];
gdjs.GameSceneCode.GDitem_95book_95hpObjects5= [];
gdjs.GameSceneCode.GDitem_95book_95hpObjects6= [];
gdjs.GameSceneCode.GDitem_95book_95hpObjects7= [];
gdjs.GameSceneCode.GDitem_95book_95hpObjects8= [];
gdjs.GameSceneCode.GDitem_95book_95expObjects1= [];
gdjs.GameSceneCode.GDitem_95book_95expObjects2= [];
gdjs.GameSceneCode.GDitem_95book_95expObjects3= [];
gdjs.GameSceneCode.GDitem_95book_95expObjects4= [];
gdjs.GameSceneCode.GDitem_95book_95expObjects5= [];
gdjs.GameSceneCode.GDitem_95book_95expObjects6= [];
gdjs.GameSceneCode.GDitem_95book_95expObjects7= [];
gdjs.GameSceneCode.GDitem_95book_95expObjects8= [];
gdjs.GameSceneCode.GDcursorObjects1= [];
gdjs.GameSceneCode.GDcursorObjects2= [];
gdjs.GameSceneCode.GDcursorObjects3= [];
gdjs.GameSceneCode.GDcursorObjects4= [];
gdjs.GameSceneCode.GDcursorObjects5= [];
gdjs.GameSceneCode.GDcursorObjects6= [];
gdjs.GameSceneCode.GDcursorObjects7= [];
gdjs.GameSceneCode.GDcursorObjects8= [];
gdjs.GameSceneCode.GDobj_95buttonsObjects1= [];
gdjs.GameSceneCode.GDobj_95buttonsObjects2= [];
gdjs.GameSceneCode.GDobj_95buttonsObjects3= [];
gdjs.GameSceneCode.GDobj_95buttonsObjects4= [];
gdjs.GameSceneCode.GDobj_95buttonsObjects5= [];
gdjs.GameSceneCode.GDobj_95buttonsObjects6= [];
gdjs.GameSceneCode.GDobj_95buttonsObjects7= [];
gdjs.GameSceneCode.GDobj_95buttonsObjects8= [];
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects1= [];
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects2= [];
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects3= [];
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects4= [];
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects5= [];
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects6= [];
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects7= [];
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects8= [];
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects1= [];
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects2= [];
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects3= [];
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects4= [];
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects5= [];
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects6= [];
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects7= [];
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects8= [];
gdjs.GameSceneCode.GDbuy_95btnObjects1= [];
gdjs.GameSceneCode.GDbuy_95btnObjects2= [];
gdjs.GameSceneCode.GDbuy_95btnObjects3= [];
gdjs.GameSceneCode.GDbuy_95btnObjects4= [];
gdjs.GameSceneCode.GDbuy_95btnObjects5= [];
gdjs.GameSceneCode.GDbuy_95btnObjects6= [];
gdjs.GameSceneCode.GDbuy_95btnObjects7= [];
gdjs.GameSceneCode.GDbuy_95btnObjects8= [];
gdjs.GameSceneCode.GDobj_95close_95btnObjects1= [];
gdjs.GameSceneCode.GDobj_95close_95btnObjects2= [];
gdjs.GameSceneCode.GDobj_95close_95btnObjects3= [];
gdjs.GameSceneCode.GDobj_95close_95btnObjects4= [];
gdjs.GameSceneCode.GDobj_95close_95btnObjects5= [];
gdjs.GameSceneCode.GDobj_95close_95btnObjects6= [];
gdjs.GameSceneCode.GDobj_95close_95btnObjects7= [];
gdjs.GameSceneCode.GDobj_95close_95btnObjects8= [];
gdjs.GameSceneCode.GDhud_95panelObjects1= [];
gdjs.GameSceneCode.GDhud_95panelObjects2= [];
gdjs.GameSceneCode.GDhud_95panelObjects3= [];
gdjs.GameSceneCode.GDhud_95panelObjects4= [];
gdjs.GameSceneCode.GDhud_95panelObjects5= [];
gdjs.GameSceneCode.GDhud_95panelObjects6= [];
gdjs.GameSceneCode.GDhud_95panelObjects7= [];
gdjs.GameSceneCode.GDhud_95panelObjects8= [];
gdjs.GameSceneCode.GDhud_95panel_95144Objects1= [];
gdjs.GameSceneCode.GDhud_95panel_95144Objects2= [];
gdjs.GameSceneCode.GDhud_95panel_95144Objects3= [];
gdjs.GameSceneCode.GDhud_95panel_95144Objects4= [];
gdjs.GameSceneCode.GDhud_95panel_95144Objects5= [];
gdjs.GameSceneCode.GDhud_95panel_95144Objects6= [];
gdjs.GameSceneCode.GDhud_95panel_95144Objects7= [];
gdjs.GameSceneCode.GDhud_95panel_95144Objects8= [];
gdjs.GameSceneCode.GDeffectObjects1= [];
gdjs.GameSceneCode.GDeffectObjects2= [];
gdjs.GameSceneCode.GDeffectObjects3= [];
gdjs.GameSceneCode.GDeffectObjects4= [];
gdjs.GameSceneCode.GDeffectObjects5= [];
gdjs.GameSceneCode.GDeffectObjects6= [];
gdjs.GameSceneCode.GDeffectObjects7= [];
gdjs.GameSceneCode.GDeffectObjects8= [];
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1= [];
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects2= [];
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects3= [];
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects4= [];
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects5= [];
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects6= [];
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects7= [];
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects8= [];
gdjs.GameSceneCode.GDhud_95panel_95256Objects1= [];
gdjs.GameSceneCode.GDhud_95panel_95256Objects2= [];
gdjs.GameSceneCode.GDhud_95panel_95256Objects3= [];
gdjs.GameSceneCode.GDhud_95panel_95256Objects4= [];
gdjs.GameSceneCode.GDhud_95panel_95256Objects5= [];
gdjs.GameSceneCode.GDhud_95panel_95256Objects6= [];
gdjs.GameSceneCode.GDhud_95panel_95256Objects7= [];
gdjs.GameSceneCode.GDhud_95panel_95256Objects8= [];
gdjs.GameSceneCode.GDcoins_95bgObjects1= [];
gdjs.GameSceneCode.GDcoins_95bgObjects2= [];
gdjs.GameSceneCode.GDcoins_95bgObjects3= [];
gdjs.GameSceneCode.GDcoins_95bgObjects4= [];
gdjs.GameSceneCode.GDcoins_95bgObjects5= [];
gdjs.GameSceneCode.GDcoins_95bgObjects6= [];
gdjs.GameSceneCode.GDcoins_95bgObjects7= [];
gdjs.GameSceneCode.GDcoins_95bgObjects8= [];
gdjs.GameSceneCode.GDcoinObjects1= [];
gdjs.GameSceneCode.GDcoinObjects2= [];
gdjs.GameSceneCode.GDcoinObjects3= [];
gdjs.GameSceneCode.GDcoinObjects4= [];
gdjs.GameSceneCode.GDcoinObjects5= [];
gdjs.GameSceneCode.GDcoinObjects6= [];
gdjs.GameSceneCode.GDcoinObjects7= [];
gdjs.GameSceneCode.GDcoinObjects8= [];
gdjs.GameSceneCode.GDselector_95btnObjects1= [];
gdjs.GameSceneCode.GDselector_95btnObjects2= [];
gdjs.GameSceneCode.GDselector_95btnObjects3= [];
gdjs.GameSceneCode.GDselector_95btnObjects4= [];
gdjs.GameSceneCode.GDselector_95btnObjects5= [];
gdjs.GameSceneCode.GDselector_95btnObjects6= [];
gdjs.GameSceneCode.GDselector_95btnObjects7= [];
gdjs.GameSceneCode.GDselector_95btnObjects8= [];
gdjs.GameSceneCode.GDcontrols_95bgObjects1= [];
gdjs.GameSceneCode.GDcontrols_95bgObjects2= [];
gdjs.GameSceneCode.GDcontrols_95bgObjects3= [];
gdjs.GameSceneCode.GDcontrols_95bgObjects4= [];
gdjs.GameSceneCode.GDcontrols_95bgObjects5= [];
gdjs.GameSceneCode.GDcontrols_95bgObjects6= [];
gdjs.GameSceneCode.GDcontrols_95bgObjects7= [];
gdjs.GameSceneCode.GDcontrols_95bgObjects8= [];

gdjs.GameSceneCode.conditionTrue_0 = {val:false};
gdjs.GameSceneCode.condition0IsTrue_0 = {val:false};
gdjs.GameSceneCode.condition1IsTrue_0 = {val:false};
gdjs.GameSceneCode.condition2IsTrue_0 = {val:false};
gdjs.GameSceneCode.condition3IsTrue_0 = {val:false};
gdjs.GameSceneCode.conditionTrue_1 = {val:false};
gdjs.GameSceneCode.condition0IsTrue_1 = {val:false};
gdjs.GameSceneCode.condition1IsTrue_1 = {val:false};
gdjs.GameSceneCode.condition2IsTrue_1 = {val:false};
gdjs.GameSceneCode.condition3IsTrue_1 = {val:false};


gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595item_9595titleObjects1Objects = Hashtable.newFrom({"txt_item_title": gdjs.GameSceneCode.GDtxt_95item_95titleObjects1});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595item_9595descObjects1Objects = Hashtable.newFrom({"txt_item_desc": gdjs.GameSceneCode.GDtxt_95item_95descObjects1});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595shop_9595item_9595titleObjects1Objects = Hashtable.newFrom({"txt_shop_item_title": gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects1});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595shop_9595item_9595descObjects1Objects = Hashtable.newFrom({"txt_shop_item_desc": gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects1});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595titleObjects1Objects = Hashtable.newFrom({"txt_title": gdjs.GameSceneCode.GDtxt_95titleObjects1});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595shop_9595moneyObjects1Objects = Hashtable.newFrom({"txt_shop_money": gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1});gdjs.GameSceneCode.eventsList0 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.sound.isMusicOnChannelPaused(runtimeScene, 1);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.continueMusicOnChannel(runtimeScene, 1);
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isMusicOnChannelPlaying(runtimeScene, 1));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playMusicOnChannel(runtimeScene, "Assets\\music\\0-main-music.mp3", 1, true, 80, 1);
}}

}


};gdjs.GameSceneCode.eventsList1 = function(runtimeScene) {

{


{
{gdjs.evtTools.sound.stopMusicOnChannel(runtimeScene, 1);
}
{ //Subevents
gdjs.GameSceneCode.eventsList0(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595titleObjects2Objects = Hashtable.newFrom({"inventory_title": gdjs.GameSceneCode.GDinventory_95titleObjects2});gdjs.GameSceneCode.eventsList2 = function(runtimeScene) {

{


{
gdjs.GameSceneCode.GDinventory_95titleObjects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595titleObjects2Objects, gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2, 24, "HUD");
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95titleObjects2[i].setGradient("LINEAR_VERTICAL", "204;150;252", "147;72;212", "90;27;146", "36;6;63");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95titleObjects2[i].setOutline("255;255;255", 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95titleObjects2[i].setTextAlignment("center");
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595title2Objects2Objects = Hashtable.newFrom({"inventory_title2": gdjs.GameSceneCode.GDinventory_95title2Objects2});gdjs.GameSceneCode.eventsList3 = function(runtimeScene) {

{


{
gdjs.GameSceneCode.GDinventory_95title2Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595title2Objects2Objects, gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2, 80, "HUD");
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95title2Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95title2Objects2[i].setOutline("0;0;0", 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95title2Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95title2Objects2[i].setTextAlignment("center");
}
}}

}


};gdjs.GameSceneCode.eventsList4 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDtxt_95titleObjects1, gdjs.GameSceneCode.GDtxt_95titleObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setWrappingWidth(256 * 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setScale(0.4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setPadding(10);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setOutline("0;0;0", 6);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setTextAlignment("center");
}
}}

}


};gdjs.GameSceneCode.eventsList5 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDtxt_95item_95titleObjects1, gdjs.GameSceneCode.GDtxt_95item_95titleObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects2[i].setWrappingWidth(256 * 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects2[i].setCharacterSize(20);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects2[i].setScale(0.4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects2[i].setOutline("0;0;0", 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects2[i].setGradient("LINEAR_VERTICAL", "255;255;255", "189;189;189", "121;121;121", "90;90;90");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects2[i].setTextAlignment("left");
}
}}

}


};gdjs.GameSceneCode.eventsList6 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDtxt_95item_95descObjects1, gdjs.GameSceneCode.GDtxt_95item_95descObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects2[i].setWrappingWidth(256 * 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects2[i].setCharacterSize(20);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects2[i].setScale(0.4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects2[i].setGradient("LINEAR_VERTICAL", "255;255;255", "189;189;189", "121;121;121", "90;90;90");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects2[i].setOutline("0;0;0", 4);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects2[i].setTextAlignment("left");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects2[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects2[i].setWrappingWidth(200);
}
}}

}


};gdjs.GameSceneCode.eventsList7 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects1, gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2[i].setOutline("0;0;0", 8);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2[i].setGradient("LINEAR_VERTICAL", "255;255;255", "189;189;189", "121;121;121", "90;90;90");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2[i].setWrapping(true);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2[i].setWrappingWidth(144 * 4);
}
}}

}


};gdjs.GameSceneCode.eventsList8 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects1, gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2[i].setCharacterSize(40);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2[i].setOutline("0;0;0", 8);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2[i].setGradient("LINEAR_VERTICAL", "255;255;255", "189;189;189", "121;121;121", "90;90;90");
}
}}

}


};gdjs.GameSceneCode.eventsList9 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1, gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2);

{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2[i].setCharacterSize(60);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2[i].setOutline("0;0;0", 8);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2[i].setGradient("LINEAR_VERTICAL", "255;248;164", "219;209;89", "151;142;33", "129;120;12");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2[i].setTextAlignment("left");
}
}}

}


};gdjs.GameSceneCode.eventsList10 = function(runtimeScene) {

{


{
{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "CONTROLS", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "SHOP", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "INVENTORY", 0, 0);
}{gdjs.evtTools.runtimeScene.createObjectsFromExternalLayout(runtimeScene, "EFFECT", 0, 0);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects1Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects1});gdjs.GameSceneCode.eventsList11 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects1);
{gdjs.evtsExt__CreateMultipleCopiesOfObject__CreateMultipleCopiesOfObject.func(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects1Objects, 3, 4, 264, 64, 8, 8, "slots", "INVENTORY", 1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}}

}


};gdjs.GameSceneCode.eventsList12 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList1(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList2(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList3(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList4(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList5(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList6(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList7(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList8(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList9(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList10(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList11(runtimeScene);
}


};gdjs.GameSceneCode.eventsList13 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("hud_panel_144x144"), gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1);
gdjs.GameSceneCode.GDtxt_95item_95descObjects1.length = 0;

gdjs.GameSceneCode.GDtxt_95item_95titleObjects1.length = 0;

gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects1.length = 0;

gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects1.length = 0;

gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1.length = 0;

gdjs.GameSceneCode.GDtxt_95titleObjects1.length = 0;

{gdjs.evtTools.input.hideCursor(runtimeScene);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("running");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "HUD");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "INVENTORY");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "SHOP");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "CONTROLS");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595item_9595titleObjects1Objects, (( gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[0].getPointX("title")), (( gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[0].getPointY("title")), "INVENTORY");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595item_9595descObjects1Objects, (( gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[0].getPointX("description")), (( gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[0].getPointY("description")), "INVENTORY");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595shop_9595item_9595titleObjects1Objects, 128, 72, "SHOP");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595shop_9595item_9595descObjects1Objects, 128, 96, "SHOP");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595titleObjects1Objects, 240, 16, "INVENTORY");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDtxt_9595shop_9595moneyObjects1Objects, 312, 317, "SHOP");
}{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[i].setZOrder(100);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects1[i].setZOrder(101);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects1[i].setZOrder(102);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects1[i].setZOrder(102);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects1[i].setZOrder(102);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1[i].setZOrder(102);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects1[i].setZOrder(300);
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595buttonsObjects3Objects = Hashtable.newFrom({"obj_buttons": gdjs.GameSceneCode.GDobj_95buttonsObjects3});gdjs.GameSceneCode.eventsList14 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9814716);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("inventory");
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\05-button.wav", 1, false, 100, 1);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595buttonsObjects3Objects = Hashtable.newFrom({"obj_buttons": gdjs.GameSceneCode.GDobj_95buttonsObjects3});gdjs.GameSceneCode.eventsList15 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9816660);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("shop");
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\05-button.wav", 1, false, 100, 1);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595buttonsObjects3Objects = Hashtable.newFrom({"obj_buttons": gdjs.GameSceneCode.GDobj_95buttonsObjects3});gdjs.GameSceneCode.eventsList16 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects5Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects5});gdjs.GameSceneCode.eventsList17 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects4, gdjs.GameSceneCode.GDinventory_95slotObjects5);


gdjs.GameSceneCode.repeatCount6 = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects5[0].getVariables()).get("nameofitem"))));
for(gdjs.GameSceneCode.repeatIndex6 = 0;gdjs.GameSceneCode.repeatIndex6 < gdjs.GameSceneCode.repeatCount6;++gdjs.GameSceneCode.repeatIndex6) {
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects5, gdjs.GameSceneCode.GDinventory_95slotObjects6);


if (true)
{
{gdjs.evtTools.inventory.remove(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects6[0].getVariables()).get("nameofitem"))));
}}
}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects4, gdjs.GameSceneCode.GDinventory_95slotObjects5);

gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects5);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects5Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects5.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects5[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects5[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects5[0].getVariables()).get("nameofitem"))))));
}
}}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects4, gdjs.GameSceneCode.GDinventory_95slotObjects5);

{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].setAnimationName("empty");
}
}}

}


};gdjs.GameSceneCode.eventsList18 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDinventory_95slotObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDinventory_95slotObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDinventory_95slotObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDinventory_95slotObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDinventory_95slotObjects4.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("nameofitem")) == "") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDinventory_95slotObjects4[k] = gdjs.GameSceneCode.GDinventory_95slotObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDinventory_95slotObjects4.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList17(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameSceneCode.eventsList19 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9818580);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\05-button.wav", 1, false, 100, 1);
}{gdjs.evtTools.storage.clearJSONFile("inventory_save");
}{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "SplashScene", true);
}
{ //Subevents
gdjs.GameSceneCode.eventsList18(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595buttonsObjects2Objects = Hashtable.newFrom({"obj_buttons": gdjs.GameSceneCode.GDobj_95buttonsObjects2});gdjs.GameSceneCode.eventsList20 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9823700);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setString("controls");
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\05-button.wav", 1, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList21 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_buttons"), gdjs.GameSceneCode.GDobj_95buttonsObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95buttonsObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95buttonsObjects3[i].isCurrentAnimationName("inventory") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95buttonsObjects3[k] = gdjs.GameSceneCode.GDobj_95buttonsObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95buttonsObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595buttonsObjects3Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList14(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("obj_buttons"), gdjs.GameSceneCode.GDobj_95buttonsObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95buttonsObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95buttonsObjects3[i].isCurrentAnimationName("shop") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95buttonsObjects3[k] = gdjs.GameSceneCode.GDobj_95buttonsObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95buttonsObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595buttonsObjects3Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList15(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("obj_buttons"), gdjs.GameSceneCode.GDobj_95buttonsObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95buttonsObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95buttonsObjects3[i].isCurrentAnimationName("delete") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95buttonsObjects3[k] = gdjs.GameSceneCode.GDobj_95buttonsObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95buttonsObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595buttonsObjects3Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList19(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("obj_buttons"), gdjs.GameSceneCode.GDobj_95buttonsObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95buttonsObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95buttonsObjects2[i].isCurrentAnimationName("controls") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95buttonsObjects2[k] = gdjs.GameSceneCode.GDobj_95buttonsObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95buttonsObjects2.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595buttonsObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition2IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList20(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList22 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "HUD");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList21(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList23 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList22(runtimeScene);
}


};gdjs.GameSceneCode.eventsList24 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "running";
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("obj_close_btn"), gdjs.GameSceneCode.GDobj_95close_95btnObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95close_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95close_95btnObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].setLayer("HUD");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList23(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList25 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "CONTROLS"));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "HUD");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "SHOP");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "INVENTORY");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "CONTROLS");
}}

}


};gdjs.GameSceneCode.eventsList26 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList25(runtimeScene);
}


};gdjs.GameSceneCode.eventsList27 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "controls";
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("obj_close_btn"), gdjs.GameSceneCode.GDobj_95close_95btnObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_title"), gdjs.GameSceneCode.GDtxt_95titleObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].setLayer("CONTROLS");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95close_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95close_95btnObjects2[i].setLayer("CONTROLS");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95close_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95close_95btnObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setLayer("CONTROLS");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setString("Controls");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList26(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects4Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects4});gdjs.GameSceneCode.eventsList28 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList29 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects6Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects6});gdjs.GameSceneCode.eventsList30 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects5, gdjs.GameSceneCode.GDinventory_95slotObjects6);


gdjs.GameSceneCode.repeatCount7 = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects6[0].getVariables()).get("nameofitem"))));
for(gdjs.GameSceneCode.repeatIndex7 = 0;gdjs.GameSceneCode.repeatIndex7 < gdjs.GameSceneCode.repeatCount7;++gdjs.GameSceneCode.repeatIndex7) {
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects6, gdjs.GameSceneCode.GDinventory_95slotObjects7);


if (true)
{
{gdjs.evtTools.inventory.remove(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects7[0].getVariables()).get("nameofitem"))));
}}
}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects5, gdjs.GameSceneCode.GDinventory_95slotObjects6);

gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects6);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects6Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects6.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects6[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects6[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects6[0].getVariables()).get("nameofitem"))))));
}
}}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects5, gdjs.GameSceneCode.GDinventory_95slotObjects6);

{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects6[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects6[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects6[i].setAnimationName("empty");
}
}}

}


};gdjs.GameSceneCode.eventsList31 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects5Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects5});gdjs.GameSceneCode.eventsList32 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.repeatCount7 = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("numberofitems"));
for(gdjs.GameSceneCode.repeatIndex7 = 0;gdjs.GameSceneCode.repeatIndex7 < gdjs.GameSceneCode.repeatCount7;++gdjs.GameSceneCode.repeatIndex7) {

if (true)
{
{gdjs.evtTools.inventory.add(runtimeScene, "player_inventory", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("nameofitem")));
}}
}

}


{


{
/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects5 */
gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects5);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects5Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects5.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects5[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects5[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects5[0].getVariables()).get("nameofitem"))))));
}
}}

}


};gdjs.GameSceneCode.eventsList33 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects4, gdjs.GameSceneCode.GDinventory_95slotObjects5);

{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("nameofitem")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("nameofitem")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("item_title")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_title")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("item_description")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_description")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("nameofitem"))));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList32(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList34 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects4);

for(gdjs.GameSceneCode.forEachIndex5 = 0;gdjs.GameSceneCode.forEachIndex5 < gdjs.GameSceneCode.GDinventory_95slotObjects4.length;++gdjs.GameSceneCode.forEachIndex5) {
gdjs.GameSceneCode.GDinventory_95slotObjects5.length = 0;


gdjs.GameSceneCode.forEachTemporary5 = gdjs.GameSceneCode.GDinventory_95slotObjects4[gdjs.GameSceneCode.forEachIndex5];
gdjs.GameSceneCode.GDinventory_95slotObjects5.push(gdjs.GameSceneCode.forEachTemporary5);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDinventory_95slotObjects5.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("nameofitem")) == "") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDinventory_95slotObjects5[k] = gdjs.GameSceneCode.GDinventory_95slotObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDinventory_95slotObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList30(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDinventory_95slotObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDinventory_95slotObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDinventory_95slotObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDinventory_95slotObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("numberofitems"));
}{gdjs.evtTools.storage.readStringFromJSONFile("inventory_save", "nameofitem" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("nameofitem"));
}{gdjs.evtTools.storage.readStringFromJSONFile("inventory_save", "item_title" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("item_title"));
}{gdjs.evtTools.storage.readStringFromJSONFile("inventory_save", "item_description" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("item_description"));
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList33(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameSceneCode.eventsList35 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects4);

gdjs.GameSceneCode.repeatCount5 = gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects4Objects);
for(gdjs.GameSceneCode.repeatIndex5 = 0;gdjs.GameSceneCode.repeatIndex5 < gdjs.GameSceneCode.repeatCount5;++gdjs.GameSceneCode.repeatIndex5) {
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects4, gdjs.GameSceneCode.GDinventory_95slotObjects5);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects5[0].getVariables()).get("ID")))));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("save_exists").setNumber(1);
}}
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("save_exists")) == 1;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList34(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList36 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "INVENTORY"));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "HUD");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "SHOP");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "CONTROLS");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "INVENTORY");
}}

}


};gdjs.GameSceneCode.eventsList37 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9829412);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList35(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.eventsList36(runtimeScene);
}


};gdjs.GameSceneCode.eventsList38 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "inventory";
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("obj_close_btn"), gdjs.GameSceneCode.GDobj_95close_95btnObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_title"), gdjs.GameSceneCode.GDtxt_95titleObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].setLayer("INVENTORY");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95close_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95close_95btnObjects2[i].setLayer("INVENTORY");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95close_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95close_95btnObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setLayer("INVENTORY");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setString("Inventory");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList37(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList39 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "SHOP"));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.hideLayer(runtimeScene, "HUD");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "INVENTORY");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "CONTROLS");
}{gdjs.evtTools.camera.showLayer(runtimeScene, "SHOP");
}}

}


};gdjs.GameSceneCode.eventsList40 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList39(runtimeScene);
}


};gdjs.GameSceneCode.eventsList41 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)) == "shop";
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects2);
gdjs.copyArray(runtimeScene.getObjects("obj_close_btn"), gdjs.GameSceneCode.GDobj_95close_95btnObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_title"), gdjs.GameSceneCode.GDtxt_95titleObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects2[i].setLayer("SHOP");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95close_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95close_95btnObjects2[i].setLayer("SHOP");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setLayer("SHOP");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDobj_95close_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDobj_95close_95btnObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects2[i].setString("shop");
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList40(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595close_9595btnObjects1Objects = Hashtable.newFrom({"obj_close_btn": gdjs.GameSceneCode.GDobj_95close_95btnObjects1});gdjs.GameSceneCode.eventsList42 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9835724);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.showLayer(runtimeScene, "HUD");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "INVENTORY");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "CONTROLS");
}{gdjs.evtTools.camera.hideLayer(runtimeScene, "SHOP");
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\05-button.wav", 1, false, 100, 1);
}{runtimeScene.getGame().getVariables().getFromIndex(0).setString("running");
}}

}


};gdjs.GameSceneCode.eventsList43 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_close_btn"), gdjs.GameSceneCode.GDobj_95close_95btnObjects1);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595close_9595btnObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95close_95btnObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95close_95btnObjects1[i].isVisible() ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95close_95btnObjects1[k] = gdjs.GameSceneCode.GDobj_95close_95btnObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95close_95btnObjects1.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList42(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList44 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.eventsList24(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList27(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList38(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList41(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList43(runtimeScene);
}


};gdjs.GameSceneCode.eventsList45 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("cursor"), gdjs.GameSceneCode.GDcursorObjects1);
gdjs.copyArray(runtimeScene.getObjects("inventory_title"), gdjs.GameSceneCode.GDinventory_95titleObjects1);
gdjs.copyArray(runtimeScene.getObjects("inventory_title2"), gdjs.GameSceneCode.GDinventory_95title2Objects1);
gdjs.copyArray(runtimeScene.getObjects("txt_shop_money"), gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1);
gdjs.copyArray(runtimeScene.getObjects("txt_title"), gdjs.GameSceneCode.GDtxt_95titleObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95titleObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95titleObjects1[i].setPosition((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.GameSceneCode.GDtxt_95titleObjects1[i].getWidth()) / 2),16);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDcursorObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDcursorObjects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95titleObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95titleObjects1[i].setPosition((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.GameSceneCode.GDinventory_95titleObjects1[i].getWidth()) / 2),(gdjs.GameSceneCode.GDinventory_95titleObjects1[i].getY()));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95title2Objects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95title2Objects1[i].setPosition((gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) / 2) - ((gdjs.GameSceneCode.GDinventory_95title2Objects1[i].getWidth()) / 2),(gdjs.GameSceneCode.GDinventory_95title2Objects1[i].getY()));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(1)));
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDpointer_9595dragobjectObjects3Objects = Hashtable.newFrom({"pointer_dragobject": gdjs.GameSceneCode.GDpointer_95dragobjectObjects3});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects4Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects4});gdjs.GameSceneCode.eventsList46 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects3Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects3});gdjs.GameSceneCode.eventsList47 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList48 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects6Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects6});gdjs.GameSceneCode.eventsList49 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects5, gdjs.GameSceneCode.GDinventory_95slotObjects6);


gdjs.GameSceneCode.repeatCount7 = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects6[0].getVariables()).get("nameofitem"))));
for(gdjs.GameSceneCode.repeatIndex7 = 0;gdjs.GameSceneCode.repeatIndex7 < gdjs.GameSceneCode.repeatCount7;++gdjs.GameSceneCode.repeatIndex7) {
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects6, gdjs.GameSceneCode.GDinventory_95slotObjects7);


if (true)
{
{gdjs.evtTools.inventory.remove(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects7[0].getVariables()).get("nameofitem"))));
}}
}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects5, gdjs.GameSceneCode.GDinventory_95slotObjects6);

gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects6);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects6Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects6.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects6[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects6[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects6[0].getVariables()).get("nameofitem"))))));
}
}}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects5, gdjs.GameSceneCode.GDinventory_95slotObjects6);

{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects6[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects6[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects6[i].setAnimationName("empty");
}
}}

}


};gdjs.GameSceneCode.eventsList50 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects5Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects5});gdjs.GameSceneCode.eventsList51 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.repeatCount7 = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("numberofitems"));
for(gdjs.GameSceneCode.repeatIndex7 = 0;gdjs.GameSceneCode.repeatIndex7 < gdjs.GameSceneCode.repeatCount7;++gdjs.GameSceneCode.repeatIndex7) {

if (true)
{
{gdjs.evtTools.inventory.add(runtimeScene, "player_inventory", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("nameofitem")));
}}
}

}


{


{
/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects5 */
gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects5);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects5Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects5.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects5[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects5[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects5[0].getVariables()).get("nameofitem"))))));
}
}}

}


};gdjs.GameSceneCode.eventsList52 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects4, gdjs.GameSceneCode.GDinventory_95slotObjects5);

{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("nameofitem")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("nameofitem")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("item_title")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_title")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("item_description")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_description")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects5.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects5[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("nameofitem"))));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList51(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList53 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects4);

for(gdjs.GameSceneCode.forEachIndex5 = 0;gdjs.GameSceneCode.forEachIndex5 < gdjs.GameSceneCode.GDinventory_95slotObjects4.length;++gdjs.GameSceneCode.forEachIndex5) {
gdjs.GameSceneCode.GDinventory_95slotObjects5.length = 0;


gdjs.GameSceneCode.forEachTemporary5 = gdjs.GameSceneCode.GDinventory_95slotObjects4[gdjs.GameSceneCode.forEachIndex5];
gdjs.GameSceneCode.GDinventory_95slotObjects5.push(gdjs.GameSceneCode.forEachTemporary5);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDinventory_95slotObjects5.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects5[i].getVariables().get("nameofitem")) == "") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDinventory_95slotObjects5[k] = gdjs.GameSceneCode.GDinventory_95slotObjects5[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDinventory_95slotObjects5.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList49(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDinventory_95slotObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDinventory_95slotObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDinventory_95slotObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDinventory_95slotObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("numberofitems"));
}{gdjs.evtTools.storage.readStringFromJSONFile("inventory_save", "nameofitem" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("nameofitem"));
}{gdjs.evtTools.storage.readStringFromJSONFile("inventory_save", "item_title" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("item_title"));
}{gdjs.evtTools.storage.readStringFromJSONFile("inventory_save", "item_description" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("item_description"));
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList52(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects3Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects3});gdjs.GameSceneCode.eventsList54 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList55 = function(runtimeScene) {

{



}


{


{
{runtimeScene.getVariables().get("id_counter").setNumber(1);
}}

}


{



}


{


{
gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDpointer_9595dragobjectObjects3Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "", 0), "INVENTORY");
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("item_title")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("item_description")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].setZOrder(3);
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDinventory_95slotObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDslot_95textObjects4.length = 0;

gdjs.GameSceneCode.GDinventory_95slotObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDinventory_95slotObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDinventory_95slotObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
if (true) {
{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("item_title")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("item_description")).setString("");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects4Objects, (( gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getPointX("slot_text")), (( gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getPointY("slot_text")), "INVENTORY");
}{gdjs.evtTools.linkedObjects.linkObjects(runtimeScene, (gdjs.GameSceneCode.GDslot_95textObjects4.length !== 0 ? gdjs.GameSceneCode.GDslot_95textObjects4[0] : null), (gdjs.GameSceneCode.GDinventory_95slotObjects4.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects4[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects4[i].setZOrder(2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("ID")).setNumber(gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("id_counter")));
}
}{runtimeScene.getVariables().get("id_counter").add(1);
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects4[i].setCharacterSize(80);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects4[i].setGradient("LINEAR_VERTICAL", "255;255;255", "187;187;187", "138;138;138", "65;65;65");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects4[i].setOutline("0;0;0", 8);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects4[i].setScale(0.2);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects4[i].setPosition(((gdjs.GameSceneCode.GDslot_95textObjects4[i].getX()) + (( gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getWidth()) / 2) - ((gdjs.GameSceneCode.GDslot_95textObjects4[i].getWidth()) / 2),((gdjs.GameSceneCode.GDslot_95textObjects4[i].getY()) + (( gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? 0 :gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getHeight())) - (gdjs.GameSceneCode.GDslot_95textObjects4[i].getHeight()));
}
}}
}

}


{



}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects3);

gdjs.GameSceneCode.repeatCount4 = gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects3Objects);
for(gdjs.GameSceneCode.repeatIndex4 = 0;gdjs.GameSceneCode.repeatIndex4 < gdjs.GameSceneCode.repeatCount4;++gdjs.GameSceneCode.repeatIndex4) {
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects3, gdjs.GameSceneCode.GDinventory_95slotObjects4);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("ID")))));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("save_exists").setNumber(1);
}}
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("save_exists")) == 1;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList53(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDslot_95textObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects3);
gdjs.GameSceneCode.GDslot_95textObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDslot_95textObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDslot_95textObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
if (true) {
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects3Objects, (gdjs.GameSceneCode.GDslot_95textObjects3.length !== 0 ? gdjs.GameSceneCode.GDslot_95textObjects3[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem"))))));
}
}}
}

}


};gdjs.GameSceneCode.eventsList56 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList55(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("pointer_dragobject"), gdjs.GameSceneCode.GDpointer_95dragobjectObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDitem_9595potion_9595hpObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595cardObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595book_9595hpObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595book_9595expObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595chickenObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595heartObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595potion_9595expObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595book_9595mpObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595potion_9595mpObjects1Objects = Hashtable.newFrom({"item_potion_hp": gdjs.GameSceneCode.GDitem_95potion_95hpObjects1, "item_card": gdjs.GameSceneCode.GDitem_95cardObjects1, "item_book_hp": gdjs.GameSceneCode.GDitem_95book_95hpObjects1, "item_book_exp": gdjs.GameSceneCode.GDitem_95book_95expObjects1, "item_chicken": gdjs.GameSceneCode.GDitem_95chickenObjects1, "item_heart": gdjs.GameSceneCode.GDitem_95heartObjects1, "item_potion_exp": gdjs.GameSceneCode.GDitem_95potion_95expObjects1, "item_book_mp": gdjs.GameSceneCode.GDitem_95book_95mpObjects1, "item_potion_mp": gdjs.GameSceneCode.GDitem_95potion_95mpObjects1});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects6Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects6});gdjs.GameSceneCode.eventsList57 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects3, gdjs.GameSceneCode.GDinventory_95slotObjects6);

gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects6);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects6Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects6.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects6[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects6[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects6[0].getVariables()).get("nameofitem"))))));
}
}}

}


};gdjs.GameSceneCode.eventsList58 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95expObjects1, gdjs.GameSceneCode.GDitem_95book_95expObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95hpObjects1, gdjs.GameSceneCode.GDitem_95book_95hpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95mpObjects1, gdjs.GameSceneCode.GDitem_95book_95mpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95cardObjects1, gdjs.GameSceneCode.GDitem_95cardObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95chickenObjects1, gdjs.GameSceneCode.GDitem_95chickenObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95heartObjects1, gdjs.GameSceneCode.GDitem_95heartObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95expObjects1, gdjs.GameSceneCode.GDitem_95potion_95expObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95hpObjects1, gdjs.GameSceneCode.GDitem_95potion_95hpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95mpObjects1, gdjs.GameSceneCode.GDitem_95potion_95mpObjects4);


gdjs.GameSceneCode.repeatCount5 = (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDitem_95potion_95mpObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95mpObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95expObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95heartObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95chickenObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95expObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95hpObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95cardObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95hpObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDitem_95potion_95hpObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95cardObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95hpObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95expObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95chickenObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95heartObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95expObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95mpObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95mpObjects4[0].getVariables()).get("quantity")));
for(gdjs.GameSceneCode.repeatIndex5 = 0;gdjs.GameSceneCode.repeatIndex5 < gdjs.GameSceneCode.repeatCount5;++gdjs.GameSceneCode.repeatIndex5) {
gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95expObjects4, gdjs.GameSceneCode.GDitem_95book_95expObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95hpObjects4, gdjs.GameSceneCode.GDitem_95book_95hpObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95mpObjects4, gdjs.GameSceneCode.GDitem_95book_95mpObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95cardObjects4, gdjs.GameSceneCode.GDitem_95cardObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95chickenObjects4, gdjs.GameSceneCode.GDitem_95chickenObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95heartObjects4, gdjs.GameSceneCode.GDitem_95heartObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95expObjects4, gdjs.GameSceneCode.GDitem_95potion_95expObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95hpObjects4, gdjs.GameSceneCode.GDitem_95potion_95hpObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95mpObjects4, gdjs.GameSceneCode.GDitem_95potion_95mpObjects5);


if (true)
{
{gdjs.evtTools.inventory.add(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDitem_95potion_95mpObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95mpObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95expObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95heartObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95chickenObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95expObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95hpObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95cardObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95hpObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDitem_95potion_95hpObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95cardObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95hpObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95expObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95chickenObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95heartObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95expObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95mpObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95mpObjects5[0].getVariables()).get("name"))));
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList57(runtimeScene);} //Subevents end.
}
}

}


{



}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95expObjects1, gdjs.GameSceneCode.GDitem_95book_95expObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95hpObjects1, gdjs.GameSceneCode.GDitem_95book_95hpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95mpObjects1, gdjs.GameSceneCode.GDitem_95book_95mpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95cardObjects1, gdjs.GameSceneCode.GDitem_95cardObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95chickenObjects1, gdjs.GameSceneCode.GDitem_95chickenObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95heartObjects1, gdjs.GameSceneCode.GDitem_95heartObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95expObjects1, gdjs.GameSceneCode.GDitem_95potion_95expObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95hpObjects1, gdjs.GameSceneCode.GDitem_95potion_95hpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95mpObjects1, gdjs.GameSceneCode.GDitem_95potion_95mpObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDitem_95potion_95hpObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95potion_95hpObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95cardObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95cardObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95book_95hpObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95book_95hpObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95book_95expObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95book_95expObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95chickenObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95chickenObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95heartObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95heartObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95potion_95expObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95potion_95expObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95book_95mpObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95book_95mpObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95potion_95mpObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95potion_95mpObjects4[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().get("picked_item").setString("");
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\01-pickup-item.wav", 1, false, 100, 1);
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects6Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects6});gdjs.GameSceneCode.eventsList59 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects3, gdjs.GameSceneCode.GDinventory_95slotObjects6);

gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects6);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects6Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects6.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects6[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects6.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects6[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects6.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects6[0].getVariables()).get("nameofitem"))))));
}
}}

}


};gdjs.GameSceneCode.eventsList60 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95expObjects3, gdjs.GameSceneCode.GDitem_95book_95expObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95hpObjects3, gdjs.GameSceneCode.GDitem_95book_95hpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95mpObjects3, gdjs.GameSceneCode.GDitem_95book_95mpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95cardObjects3, gdjs.GameSceneCode.GDitem_95cardObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95chickenObjects3, gdjs.GameSceneCode.GDitem_95chickenObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95heartObjects3, gdjs.GameSceneCode.GDitem_95heartObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95expObjects3, gdjs.GameSceneCode.GDitem_95potion_95expObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95hpObjects3, gdjs.GameSceneCode.GDitem_95potion_95hpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95mpObjects3, gdjs.GameSceneCode.GDitem_95potion_95mpObjects4);


gdjs.GameSceneCode.repeatCount5 = (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDitem_95potion_95mpObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95mpObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95expObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95heartObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95chickenObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95expObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95hpObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95cardObjects4.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95hpObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDitem_95potion_95hpObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95cardObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95hpObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95expObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95chickenObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95heartObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95expObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95mpObjects4[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95mpObjects4[0].getVariables()).get("quantity")));
for(gdjs.GameSceneCode.repeatIndex5 = 0;gdjs.GameSceneCode.repeatIndex5 < gdjs.GameSceneCode.repeatCount5;++gdjs.GameSceneCode.repeatIndex5) {
gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95expObjects4, gdjs.GameSceneCode.GDitem_95book_95expObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95hpObjects4, gdjs.GameSceneCode.GDitem_95book_95hpObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95mpObjects4, gdjs.GameSceneCode.GDitem_95book_95mpObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95cardObjects4, gdjs.GameSceneCode.GDitem_95cardObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95chickenObjects4, gdjs.GameSceneCode.GDitem_95chickenObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95heartObjects4, gdjs.GameSceneCode.GDitem_95heartObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95expObjects4, gdjs.GameSceneCode.GDitem_95potion_95expObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95hpObjects4, gdjs.GameSceneCode.GDitem_95potion_95hpObjects5);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95mpObjects4, gdjs.GameSceneCode.GDitem_95potion_95mpObjects5);


if (true)
{
{gdjs.evtTools.inventory.add(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDitem_95potion_95mpObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95mpObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95expObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95heartObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95chickenObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95expObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95hpObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95cardObjects5.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95hpObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDitem_95potion_95hpObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95cardObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95hpObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95expObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95chickenObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95heartObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95expObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95mpObjects5[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95mpObjects5[0].getVariables()).get("name"))));
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList59(runtimeScene);} //Subevents end.
}
}

}


{



}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95expObjects3, gdjs.GameSceneCode.GDitem_95book_95expObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95hpObjects3, gdjs.GameSceneCode.GDitem_95book_95hpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95mpObjects3, gdjs.GameSceneCode.GDitem_95book_95mpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95cardObjects3, gdjs.GameSceneCode.GDitem_95cardObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95chickenObjects3, gdjs.GameSceneCode.GDitem_95chickenObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95heartObjects3, gdjs.GameSceneCode.GDitem_95heartObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95expObjects3, gdjs.GameSceneCode.GDitem_95potion_95expObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95hpObjects3, gdjs.GameSceneCode.GDitem_95potion_95hpObjects4);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95mpObjects3, gdjs.GameSceneCode.GDitem_95potion_95mpObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDitem_95potion_95hpObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95potion_95hpObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95cardObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95cardObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95book_95hpObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95book_95hpObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95book_95expObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95book_95expObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95chickenObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95chickenObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95heartObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95heartObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95potion_95expObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95potion_95expObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95book_95mpObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95book_95mpObjects4[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs.GameSceneCode.GDitem_95potion_95mpObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDitem_95potion_95mpObjects4[i].deleteFromScene(runtimeScene);
}
}{runtimeScene.getVariables().get("picked_item").setString("");
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\01-pickup-item.wav", 1, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList61 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDinventory_95slotObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDinventory_95slotObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDinventory_95slotObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDinventory_95slotObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDinventory_95slotObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("picked_item")) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDinventory_95slotObjects3[k] = gdjs.GameSceneCode.GDinventory_95slotObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDinventory_95slotObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = !(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("picked_item")) == "");
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList58(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDinventory_95slotObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95expObjects1, gdjs.GameSceneCode.GDitem_95book_95expObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95hpObjects1, gdjs.GameSceneCode.GDitem_95book_95hpObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95book_95mpObjects1, gdjs.GameSceneCode.GDitem_95book_95mpObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95cardObjects1, gdjs.GameSceneCode.GDitem_95cardObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95chickenObjects1, gdjs.GameSceneCode.GDitem_95chickenObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95heartObjects1, gdjs.GameSceneCode.GDitem_95heartObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95expObjects1, gdjs.GameSceneCode.GDitem_95potion_95expObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95hpObjects1, gdjs.GameSceneCode.GDitem_95potion_95hpObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDitem_95potion_95mpObjects1, gdjs.GameSceneCode.GDitem_95potion_95mpObjects3);

gdjs.GameSceneCode.GDinventory_95slotObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDinventory_95slotObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDinventory_95slotObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDinventory_95slotObjects3.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem")) == "" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDinventory_95slotObjects3[k] = gdjs.GameSceneCode.GDinventory_95slotObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDinventory_95slotObjects3.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = !(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("picked_item")) == "");
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDitem_95potion_95mpObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95mpObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95expObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95heartObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95chickenObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95expObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95hpObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95cardObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95hpObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDitem_95potion_95hpObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95cardObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95hpObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95expObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95chickenObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95heartObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95expObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95mpObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95mpObjects3[0].getVariables()).get("name"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("item_title")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDitem_95potion_95mpObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95mpObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95expObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95heartObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95chickenObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95expObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95hpObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95cardObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95hpObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDitem_95potion_95hpObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95cardObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95hpObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95expObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95chickenObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95heartObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95expObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95mpObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95mpObjects3[0].getVariables()).get("title"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("item_description")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDitem_95potion_95mpObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95mpObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95expObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95heartObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95chickenObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95expObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95hpObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95cardObjects3.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95hpObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDitem_95potion_95hpObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95cardObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95hpObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95expObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95chickenObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95heartObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95expObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95mpObjects3[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95mpObjects3[0].getVariables()).get("description"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem"))));
}
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList60(runtimeScene);} //Subevents end.
}
}

}


{



}


{



}


};gdjs.GameSceneCode.eventsList62 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("item_book_exp"), gdjs.GameSceneCode.GDitem_95book_95expObjects1);
gdjs.copyArray(runtimeScene.getObjects("item_book_hp"), gdjs.GameSceneCode.GDitem_95book_95hpObjects1);
gdjs.copyArray(runtimeScene.getObjects("item_book_mp"), gdjs.GameSceneCode.GDitem_95book_95mpObjects1);
gdjs.copyArray(runtimeScene.getObjects("item_card"), gdjs.GameSceneCode.GDitem_95cardObjects1);
gdjs.copyArray(runtimeScene.getObjects("item_chicken"), gdjs.GameSceneCode.GDitem_95chickenObjects1);
gdjs.copyArray(runtimeScene.getObjects("item_heart"), gdjs.GameSceneCode.GDitem_95heartObjects1);
gdjs.copyArray(runtimeScene.getObjects("item_potion_exp"), gdjs.GameSceneCode.GDitem_95potion_95expObjects1);
gdjs.copyArray(runtimeScene.getObjects("item_potion_hp"), gdjs.GameSceneCode.GDitem_95potion_95hpObjects1);
gdjs.copyArray(runtimeScene.getObjects("item_potion_mp"), gdjs.GameSceneCode.GDitem_95potion_95mpObjects1);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDitem_9595potion_9595hpObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595cardObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595book_9595hpObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595book_9595expObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595chickenObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595heartObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595potion_9595expObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595book_9595mpObjects1ObjectsGDgdjs_46GameSceneCode_46GDitem_9595potion_9595mpObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDitem_95book_95expObjects1 */
/* Reuse gdjs.GameSceneCode.GDitem_95book_95hpObjects1 */
/* Reuse gdjs.GameSceneCode.GDitem_95book_95mpObjects1 */
/* Reuse gdjs.GameSceneCode.GDitem_95cardObjects1 */
/* Reuse gdjs.GameSceneCode.GDitem_95chickenObjects1 */
/* Reuse gdjs.GameSceneCode.GDitem_95heartObjects1 */
/* Reuse gdjs.GameSceneCode.GDitem_95potion_95expObjects1 */
/* Reuse gdjs.GameSceneCode.GDitem_95potion_95hpObjects1 */
/* Reuse gdjs.GameSceneCode.GDitem_95potion_95mpObjects1 */
{runtimeScene.getVariables().get("picked_item").setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDitem_95potion_95mpObjects1.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95mpObjects1.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95expObjects1.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95heartObjects1.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95chickenObjects1.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95expObjects1.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95book_95hpObjects1.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95cardObjects1.length === 0 ) ? ((gdjs.GameSceneCode.GDitem_95potion_95hpObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDitem_95potion_95hpObjects1[0].getVariables()) : gdjs.GameSceneCode.GDitem_95cardObjects1[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95hpObjects1[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95expObjects1[0].getVariables()) : gdjs.GameSceneCode.GDitem_95chickenObjects1[0].getVariables()) : gdjs.GameSceneCode.GDitem_95heartObjects1[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95expObjects1[0].getVariables()) : gdjs.GameSceneCode.GDitem_95book_95mpObjects1[0].getVariables()) : gdjs.GameSceneCode.GDitem_95potion_95mpObjects1[0].getVariables()).get("name"))));
}
{ //Subevents
gdjs.GameSceneCode.eventsList61(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects1Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects1});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects2Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects2});gdjs.GameSceneCode.eventsList63 = function(runtimeScene) {

{



}


{


{
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\03-energy.wav", 1, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList64 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects1, gdjs.GameSceneCode.GDinventory_95slotObjects2);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("nameofitem")))) > 0;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects2 */
gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects2);
{gdjs.evtTools.inventory.remove(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("nameofitem"))));
}{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects2Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects2.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects2[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects2[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("nameofitem"))))));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList63(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects1, gdjs.GameSceneCode.GDinventory_95slotObjects2);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("nameofitem")))) == 0;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects2[i].setAnimationName("empty");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects2[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects2[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects2[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects2[i].getVariables().get("item_title")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects2[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects2[i].getVariables().get("item_description")).setString("");
}
}}

}


{



}


{



}


};gdjs.GameSceneCode.eventsList65 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects1);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Right");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects1Objects, runtimeScene, true, false);
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList64(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList66 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "INVENTORY");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList65(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects2Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects2Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects2});gdjs.GameSceneCode.eventsList67 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("pointer_dragobject"), gdjs.GameSceneCode.GDpointer_95dragobjectObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDpointer_95dragobjectObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].getVariableString(gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].getVariables().get("nameofitem")) == "" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[k] = gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDpointer_95dragobjectObjects2.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects2 */
/* Reuse gdjs.GameSceneCode.GDpointer_95dragobjectObjects2 */
gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].getVariables().get("nameofitem")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("nameofitem"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].getVariables().get("item_title")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("item_title"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].getVariables().get("item_description")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("item_description"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDpointer_95dragobjectObjects2[i].getVariables().get("nameofitem"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects2[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects2[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects2[i].setAnimationName("empty");
}
}{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects2Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects2.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects2[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects2[i].setString("0");
}
}}

}


};gdjs.GameSceneCode.eventsList68 = function(runtimeScene) {

{



}


{

/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects2 */

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("nameofitem")))) > 0;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList67(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects2Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects3Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects3});gdjs.GameSceneCode.eventsList69 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("pointer_dragobject"), gdjs.GameSceneCode.GDpointer_95dragobjectObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariableString(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("nameofitem")) == "") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[k] = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects3 */
/* Reuse gdjs.GameSceneCode.GDpointer_95dragobjectObjects3 */
gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects3);
{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[0].getVariables()).get("nameofitem"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("item_title")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[0].getVariables()).get("item_title"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("item_description")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[0].getVariables()).get("item_description"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem"))));
}
}{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects3Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects3.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects3[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem"))))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("item_title")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("item_description")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].setAnimationName("empty");
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects3Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects3});gdjs.GameSceneCode.eventsList70 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("pointer_dragobject"), gdjs.GameSceneCode.GDpointer_95dragobjectObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariableString(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("nameofitem")) == "") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[k] = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects3 */
/* Reuse gdjs.GameSceneCode.GDpointer_95dragobjectObjects3 */
gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects3);
{runtimeScene.getVariables().get("nameofitem").setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem"))));
}{runtimeScene.getVariables().get("item_title").setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("item_title"))));
}{runtimeScene.getVariables().get("item_description").setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("item_description"))));
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[0].getVariables()).get("nameofitem"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("item_title")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[0].getVariables()).get("item_title"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("item_description")).setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[0].getVariables()).get("item_description"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem"))));
}
}{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects3Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects3.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects3[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem"))))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("nameofitem")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("nameofitem")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("item_description")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_description")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("item_title")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_title")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].setAnimationName(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("nameofitem")));
}
}}

}


};gdjs.GameSceneCode.eventsList71 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\05-button.wav", 1, false, 100, 1);
}}

}


{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects2, gdjs.GameSceneCode.GDinventory_95slotObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem")))) == 0;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList69(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects2, gdjs.GameSceneCode.GDinventory_95slotObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem")))) > 0;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList70(runtimeScene);} //End of subevents
}

}


{



}


{



}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects2Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects1Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects1});gdjs.GameSceneCode.eventsList72 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects2Objects, runtimeScene, true, true);
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("hud_panel_144x144"), gdjs.GameSceneCode.GDhud_95panel_95144x144Objects2);
gdjs.copyArray(runtimeScene.getObjects("txt_item_desc"), gdjs.GameSceneCode.GDtxt_95item_95descObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_item_title"), gdjs.GameSceneCode.GDtxt_95item_95titleObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95panel_95144x144Objects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95panel_95144x144Objects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects2[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects2[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects1);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDinventory_95slotObjects1.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDinventory_95slotObjects1[i].isCurrentAnimationName("empty")) ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDinventory_95slotObjects1[k] = gdjs.GameSceneCode.GDinventory_95slotObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDinventory_95slotObjects1.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("hud_panel_144x144"), gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1);
/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects1 */
gdjs.copyArray(runtimeScene.getObjects("txt_item_desc"), gdjs.GameSceneCode.GDtxt_95item_95descObjects1);
gdjs.copyArray(runtimeScene.getObjects("txt_item_title"), gdjs.GameSceneCode.GDtxt_95item_95titleObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[i].setPosition(gdjs.evtTools.input.getMouseX(runtimeScene, "", 0),gdjs.evtTools.input.getMouseY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects1[i].setPosition((( gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[0].getPointX("title")),(( gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[0].getPointY("title")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects1[i].setPosition((( gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[0].getPointX("description")),(( gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1[0].getPointY("description")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95titleObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95titleObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects1[0].getVariables()).get("item_title"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95item_95descObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95item_95descObjects1[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects1[0].getVariables()).get("item_description"))));
}
}}

}


};gdjs.GameSceneCode.eventsList73 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition2IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9915300);
}
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList68(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition2IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9920508);
}
}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList71(runtimeScene);} //End of subevents
}

}


{


gdjs.GameSceneCode.eventsList72(runtimeScene);
}


};gdjs.GameSceneCode.eventsList74 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "INVENTORY");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList73(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595binObjects2Objects = Hashtable.newFrom({"inventory_bin": gdjs.GameSceneCode.GDinventory_95binObjects2});gdjs.GameSceneCode.eventsList75 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList76 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3, gdjs.GameSceneCode.GDpointer_95dragobjectObjects4);


gdjs.GameSceneCode.repeatCount5 = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDpointer_95dragobjectObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDpointer_95dragobjectObjects4[0].getVariables()).get("nameofitem"))));
for(gdjs.GameSceneCode.repeatIndex5 = 0;gdjs.GameSceneCode.repeatIndex5 < gdjs.GameSceneCode.repeatCount5;++gdjs.GameSceneCode.repeatIndex5) {
gdjs.copyArray(gdjs.GameSceneCode.GDpointer_95dragobjectObjects4, gdjs.GameSceneCode.GDpointer_95dragobjectObjects5);


if (true)
{
{gdjs.evtTools.inventory.remove(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDpointer_95dragobjectObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDpointer_95dragobjectObjects5[0].getVariables()).get("nameofitem"))));
}}
}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3, gdjs.GameSceneCode.GDpointer_95dragobjectObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects4[i].returnVariable(gdjs.GameSceneCode.GDpointer_95dragobjectObjects4[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDpointer_95dragobjectObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDpointer_95dragobjectObjects4[i].setAnimationName("empty");
}
}}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.sound.isSoundOnChannelPlaying(runtimeScene, 1));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\08-trash.wav", 1, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList77 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("pointer_dragobject"), gdjs.GameSceneCode.GDpointer_95dragobjectObjects3);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariableString(gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i].getVariables().get("nameofitem")) == "") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[k] = gdjs.GameSceneCode.GDpointer_95dragobjectObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList76(runtimeScene);} //End of subevents
}

}


{



}


{



}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595binObjects2Objects = Hashtable.newFrom({"inventory_bin": gdjs.GameSceneCode.GDinventory_95binObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595binObjects1Objects = Hashtable.newFrom({"inventory_bin": gdjs.GameSceneCode.GDinventory_95binObjects1});gdjs.GameSceneCode.eventsList78 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_bin"), gdjs.GameSceneCode.GDinventory_95binObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595binObjects2Objects, runtimeScene, true, false);
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList77(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_bin"), gdjs.GameSceneCode.GDinventory_95binObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595binObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition1IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9943300);
}
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDinventory_95binObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95binObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95binObjects2[i].setAnimation(1);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_bin"), gdjs.GameSceneCode.GDinventory_95binObjects1);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595binObjects1Objects, runtimeScene, true, true);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition1IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9943964);
}
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDinventory_95binObjects1 */
{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95binObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95binObjects1[i].setAnimation(0);
}
}}

}


};gdjs.GameSceneCode.eventsList79 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "INVENTORY");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList78(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595save_9595loadObjects2Objects = Hashtable.newFrom({"obj_btn_save_load": gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects2});gdjs.GameSceneCode.eventsList80 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList81 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDinventory_95slotObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDinventory_95slotObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDinventory_95slotObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDinventory_95slotObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
if (true) {
{gdjs.evtTools.storage.writeStringInJSONFile("inventory_save", "nameofitem" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("ID")))), (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem"))));
}{gdjs.evtTools.storage.writeStringInJSONFile("inventory_save", "item_title" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("ID")))), (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("item_title"))));
}{gdjs.evtTools.storage.writeStringInJSONFile("inventory_save", "item_description" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("ID")))), (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("item_description"))));
}{gdjs.evtTools.storage.writeNumberInJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("ID")))), gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem")))));
}}
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595save_9595loadObjects1Objects = Hashtable.newFrom({"obj_btn_save_load": gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects1});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects2Objects = Hashtable.newFrom({"inventory_slot": gdjs.GameSceneCode.GDinventory_95slotObjects2});gdjs.GameSceneCode.eventsList82 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList83 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects4Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects4});gdjs.GameSceneCode.eventsList84 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects3, gdjs.GameSceneCode.GDinventory_95slotObjects4);


gdjs.GameSceneCode.repeatCount5 = gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("nameofitem"))));
for(gdjs.GameSceneCode.repeatIndex5 = 0;gdjs.GameSceneCode.repeatIndex5 < gdjs.GameSceneCode.repeatCount5;++gdjs.GameSceneCode.repeatIndex5) {
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects4, gdjs.GameSceneCode.GDinventory_95slotObjects5);


if (true)
{
{gdjs.evtTools.inventory.remove(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects5.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects5[0].getVariables()).get("nameofitem"))));
}}
}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects3, gdjs.GameSceneCode.GDinventory_95slotObjects4);

gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects4);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects4Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects4.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects4[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects4[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects4[0].getVariables()).get("nameofitem"))))));
}
}}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects3, gdjs.GameSceneCode.GDinventory_95slotObjects4);

{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("nameofitem")).setString("");
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].setAnimationName("empty");
}
}}

}


};gdjs.GameSceneCode.eventsList85 = function(runtimeScene) {

};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects3Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects3});gdjs.GameSceneCode.eventsList86 = function(runtimeScene) {

{



}


{


gdjs.GameSceneCode.repeatCount5 = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("numberofitems"));
for(gdjs.GameSceneCode.repeatIndex5 = 0;gdjs.GameSceneCode.repeatIndex5 < gdjs.GameSceneCode.repeatCount5;++gdjs.GameSceneCode.repeatIndex5) {

if (true)
{
{gdjs.evtTools.inventory.add(runtimeScene, "player_inventory", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("nameofitem")));
}}
}

}


{


{
/* Reuse gdjs.GameSceneCode.GDinventory_95slotObjects3 */
gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects3);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects3Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects3.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects3[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects3[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem"))))));
}
}}

}


};gdjs.GameSceneCode.eventsList87 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects2, gdjs.GameSceneCode.GDinventory_95slotObjects3);

{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("nameofitem")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("item_title")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_title")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("item_description")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_description")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects3[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem"))));
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList86(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList88 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDinventory_95slotObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDinventory_95slotObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDinventory_95slotObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDinventory_95slotObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDinventory_95slotObjects3.length;i<l;++i) {
    if ( !(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects3[i].getVariables().get("nameofitem")) == "") ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDinventory_95slotObjects3[k] = gdjs.GameSceneCode.GDinventory_95slotObjects3[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDinventory_95slotObjects3.length = k;}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs.GameSceneCode.eventsList84(runtimeScene);} //Subevents end.
}
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects1);

for(gdjs.GameSceneCode.forEachIndex2 = 0;gdjs.GameSceneCode.forEachIndex2 < gdjs.GameSceneCode.GDinventory_95slotObjects1.length;++gdjs.GameSceneCode.forEachIndex2) {
gdjs.GameSceneCode.GDinventory_95slotObjects2.length = 0;


gdjs.GameSceneCode.forEachTemporary2 = gdjs.GameSceneCode.GDinventory_95slotObjects1[gdjs.GameSceneCode.forEachIndex2];
gdjs.GameSceneCode.GDinventory_95slotObjects2.push(gdjs.GameSceneCode.forEachTemporary2);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("ID")))));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
{gdjs.evtTools.storage.readNumberFromJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("numberofitems"));
}{gdjs.evtTools.storage.readStringFromJSONFile("inventory_save", "nameofitem" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("nameofitem"));
}{gdjs.evtTools.storage.readStringFromJSONFile("inventory_save", "item_title" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("item_title"));
}{gdjs.evtTools.storage.readStringFromJSONFile("inventory_save", "item_description" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects2[0].getVariables()).get("ID")))), runtimeScene, runtimeScene.getVariables().get("item_description"));
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList87(runtimeScene);} //Subevents end.
}
}

}


};gdjs.GameSceneCode.eventsList89 = function(runtimeScene) {

{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects2);

gdjs.GameSceneCode.repeatCount3 = gdjs.evtTools.object.pickedObjectsCount(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDinventory_9595slotObjects2Objects);
for(gdjs.GameSceneCode.repeatIndex3 = 0;gdjs.GameSceneCode.repeatIndex3 < gdjs.GameSceneCode.repeatCount3;++gdjs.GameSceneCode.repeatIndex3) {
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects2, gdjs.GameSceneCode.GDinventory_95slotObjects3);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.storage.elementExistsInJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("ID")))));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val)
{
{runtimeScene.getVariables().get("save_exists").setNumber(1);
}}
}

}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().get("save_exists")) == 1;
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList88(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList90 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_save_load"), gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects2);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595save_9595loadObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects2[i].isCurrentAnimationName("save") ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects2[k] = gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects2.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\05-button.wav", 1, false, 100, 1);
}
{ //Subevents
gdjs.GameSceneCode.eventsList81(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("obj_btn_save_load"), gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects1);

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDobj_9595btn_9595save_9595loadObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects1[i].isCurrentAnimationName("load") ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects1[k] = gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects1.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\05-button.wav", 1, false, 100, 1);
}
{ //Subevents
gdjs.GameSceneCode.eventsList89(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList91 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition1IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9945268);
}
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList90(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList92 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = !(gdjs.evtTools.camera.layerIsVisible(runtimeScene, "SHOP"));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("selector_btn"), gdjs.GameSceneCode.GDselector_95btnObjects1);
gdjs.copyArray(runtimeScene.getObjects("shop_slot"), gdjs.GameSceneCode.GDshop_95slotObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDshop_95slotObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDshop_95slotObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDselector_95btnObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDselector_95btnObjects1[i].hide();
}
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDshop_9595slotObjects2Objects = Hashtable.newFrom({"shop_slot": gdjs.GameSceneCode.GDshop_95slotObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDshop_9595slotObjects2Objects = Hashtable.newFrom({"shop_slot": gdjs.GameSceneCode.GDshop_95slotObjects2});gdjs.GameSceneCode.eventsList93 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9954260);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDselector_95btnObjects2 */
/* Reuse gdjs.GameSceneCode.GDshop_95slotObjects2 */
{for(var i = 0, len = gdjs.GameSceneCode.GDselector_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDselector_95btnObjects2[i].setPosition((( gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDshop_95slotObjects2[0].getPointX("")),(( gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDshop_95slotObjects2[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDselector_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDselector_95btnObjects2[i].setAnimationName("selected");
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\06-clap-klick.wav", 1, false, 100, 1);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "buytime");
}{runtimeScene.getVariables().get("item_shop_picked").setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDshop_95slotObjects2[0].getVariables()).get("name"))));
}{runtimeScene.getVariables().get("item_shop_title").setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDshop_95slotObjects2[0].getVariables()).get("title"))));
}{runtimeScene.getVariables().get("item_shop_description").setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDshop_95slotObjects2[0].getVariables()).get("description"))));
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDbuy_9595btnObjects2Objects = Hashtable.newFrom({"buy_btn": gdjs.GameSceneCode.GDbuy_95btnObjects2});gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects7Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects7});gdjs.GameSceneCode.eventsList94 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects4, gdjs.GameSceneCode.GDinventory_95slotObjects7);

gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects7);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects7Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects7.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects7[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects7.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects7[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects7[0].getVariables()).get("nameofitem"))))));
}
}}

}


};gdjs.GameSceneCode.eventsList95 = function(runtimeScene) {

{


gdjs.GameSceneCode.repeatCount6 = 1;
for(gdjs.GameSceneCode.repeatIndex6 = 0;gdjs.GameSceneCode.repeatIndex6 < gdjs.GameSceneCode.repeatCount6;++gdjs.GameSceneCode.repeatIndex6) {

if (true)
{
{gdjs.evtTools.inventory.add(runtimeScene, "player_inventory", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_picked")));
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList94(runtimeScene);} //Subevents end.
}
}

}


{


{
{runtimeScene.getVariables().get("item_shop_picked").setString("");
}{runtimeScene.getVariables().get("item_shop_title").setString("");
}{runtimeScene.getVariables().get("item_shop_description").setString("");
}}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects7Objects = Hashtable.newFrom({"slot_text": gdjs.GameSceneCode.GDslot_95textObjects7});gdjs.GameSceneCode.eventsList96 = function(runtimeScene) {

{


{
gdjs.copyArray(gdjs.GameSceneCode.GDinventory_95slotObjects4, gdjs.GameSceneCode.GDinventory_95slotObjects7);

gdjs.copyArray(runtimeScene.getObjects("slot_text"), gdjs.GameSceneCode.GDslot_95textObjects7);
{gdjs.evtTools.linkedObjects.pickObjectsLinkedTo(runtimeScene, gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDslot_9595textObjects7Objects, (gdjs.GameSceneCode.GDinventory_95slotObjects7.length !== 0 ? gdjs.GameSceneCode.GDinventory_95slotObjects7[0] : null));
}{for(var i = 0, len = gdjs.GameSceneCode.GDslot_95textObjects7.length ;i < len;++i) {
    gdjs.GameSceneCode.GDslot_95textObjects7[i].setString(gdjs.evtTools.common.toString(gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects7.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects7[0].getVariables()).get("nameofitem"))))));
}
}}

}


};gdjs.GameSceneCode.eventsList97 = function(runtimeScene) {

{


gdjs.GameSceneCode.repeatCount6 = 1;
for(gdjs.GameSceneCode.repeatIndex6 = 0;gdjs.GameSceneCode.repeatIndex6 < gdjs.GameSceneCode.repeatCount6;++gdjs.GameSceneCode.repeatIndex6) {

if (true)
{
{gdjs.evtTools.inventory.add(runtimeScene, "player_inventory", gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_picked")));
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList96(runtimeScene);} //Subevents end.
}
}

}


{


{
{runtimeScene.getVariables().get("item_shop_picked").setString("");
}{runtimeScene.getVariables().get("item_shop_title").setString("");
}{runtimeScene.getVariables().get("item_shop_description").setString("");
}}

}


};gdjs.GameSceneCode.eventsList98 = function(runtimeScene) {

};gdjs.GameSceneCode.eventsList99 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDinventory_95slotObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDinventory_95slotObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDinventory_95slotObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDinventory_95slotObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDinventory_95slotObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("nameofitem")) == gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_picked")) ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDinventory_95slotObjects4[k] = gdjs.GameSceneCode.GDinventory_95slotObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDinventory_95slotObjects4.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = !(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_picked")) == "");
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("nameofitem")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_picked")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("item_description")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_description")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("item_title")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_title")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("nameofitem"))));
}
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList95(runtimeScene);} //Subevents end.
}
}

}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects3);

for(gdjs.GameSceneCode.forEachIndex4 = 0;gdjs.GameSceneCode.forEachIndex4 < gdjs.GameSceneCode.GDinventory_95slotObjects3.length;++gdjs.GameSceneCode.forEachIndex4) {
gdjs.GameSceneCode.GDinventory_95slotObjects4.length = 0;


gdjs.GameSceneCode.forEachTemporary4 = gdjs.GameSceneCode.GDinventory_95slotObjects3[gdjs.GameSceneCode.forEachIndex4];
gdjs.GameSceneCode.GDinventory_95slotObjects4.push(gdjs.GameSceneCode.forEachTemporary4);
gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDinventory_95slotObjects4.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("nameofitem")) == "" ) {
        gdjs.GameSceneCode.condition0IsTrue_0.val = true;
        gdjs.GameSceneCode.GDinventory_95slotObjects4[k] = gdjs.GameSceneCode.GDinventory_95slotObjects4[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDinventory_95slotObjects4.length = k;}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = !(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_picked")) == "");
}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("nameofitem")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_picked")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("item_title")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_title")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].returnVariable(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("item_description")).setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().get("item_shop_description")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDinventory_95slotObjects4.length ;i < len;++i) {
    gdjs.GameSceneCode.GDinventory_95slotObjects4[i].setAnimationName((gdjs.RuntimeObject.getVariableString(gdjs.GameSceneCode.GDinventory_95slotObjects4[i].getVariables().get("nameofitem"))));
}
}
{ //Subevents: 
gdjs.GameSceneCode.eventsList97(runtimeScene);} //Subevents end.
}
}

}


{


{
gdjs.copyArray(gdjs.GameSceneCode.GDselector_95btnObjects2, gdjs.GameSceneCode.GDselector_95btnObjects3);

gdjs.copyArray(gdjs.GameSceneCode.GDshop_95slotObjects2, gdjs.GameSceneCode.GDshop_95slotObjects3);

{runtimeScene.getGame().getVariables().getFromIndex(1).sub((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDshop_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDshop_95slotObjects3[0].getVariables()).get("price"))));
}{for(var i = 0, len = gdjs.GameSceneCode.GDselector_95btnObjects3.length ;i < len;++i) {
    gdjs.GameSceneCode.GDselector_95btnObjects3[i].setAnimationName("highlight");
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\04-cash-register.wav", 1, false, 100, 1);
}}

}


{



}


{



}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("inventory_slot"), gdjs.GameSceneCode.GDinventory_95slotObjects2);

for(gdjs.GameSceneCode.forEachIndex3 = 0;gdjs.GameSceneCode.forEachIndex3 < gdjs.GameSceneCode.GDinventory_95slotObjects2.length;++gdjs.GameSceneCode.forEachIndex3) {
gdjs.GameSceneCode.GDinventory_95slotObjects3.length = 0;


gdjs.GameSceneCode.forEachTemporary3 = gdjs.GameSceneCode.GDinventory_95slotObjects2[gdjs.GameSceneCode.forEachIndex3];
gdjs.GameSceneCode.GDinventory_95slotObjects3.push(gdjs.GameSceneCode.forEachTemporary3);
if (true) {
{gdjs.evtTools.storage.writeStringInJSONFile("inventory_save", "nameofitem" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("ID")))), (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem"))));
}{gdjs.evtTools.storage.writeStringInJSONFile("inventory_save", "item_title" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("ID")))), (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("item_title"))));
}{gdjs.evtTools.storage.writeStringInJSONFile("inventory_save", "item_description" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("ID")))), (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("item_description"))));
}{gdjs.evtTools.storage.writeNumberInJSONFile("inventory_save", "numberofitems" + gdjs.evtTools.common.toString((gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("ID")))), gdjs.evtTools.inventory.count(runtimeScene, "player_inventory", (gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDinventory_95slotObjects3.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDinventory_95slotObjects3[0].getVariables()).get("nameofitem")))));
}}
}

}


};gdjs.GameSceneCode.eventsList100 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameSceneCode.GDshop_95slotObjects1, gdjs.GameSceneCode.GDshop_95slotObjects2);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(1)) > (gdjs.RuntimeObject.getVariableNumber(((gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDshop_95slotObjects2[0].getVariables()).get("price")));
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList99(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList101 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9957748);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList100(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDshop_9595slotObjects1Objects = Hashtable.newFrom({"shop_slot": gdjs.GameSceneCode.GDshop_95slotObjects1});gdjs.GameSceneCode.eventsList102 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
{gdjs.GameSceneCode.conditionTrue_1 = gdjs.GameSceneCode.condition0IsTrue_0;
gdjs.GameSceneCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9971300);
}
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDselector_95btnObjects1 */
/* Reuse gdjs.GameSceneCode.GDshop_95slotObjects1 */
{for(var i = 0, len = gdjs.GameSceneCode.GDselector_95btnObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDselector_95btnObjects1[i].setPosition((( gdjs.GameSceneCode.GDshop_95slotObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDshop_95slotObjects1[0].getPointX("")),(( gdjs.GameSceneCode.GDshop_95slotObjects1.length === 0 ) ? 0 :gdjs.GameSceneCode.GDshop_95slotObjects1[0].getPointY("")));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDselector_95btnObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDselector_95btnObjects1[i].setAnimationName("highlight");
}
}{gdjs.evtTools.sound.playSoundOnChannel(runtimeScene, "Assets\\sounds\\06-clap-klick.wav", 1, false, 100, 1);
}}

}


};gdjs.GameSceneCode.eventsList103 = function(runtimeScene) {

{

/* Reuse gdjs.GameSceneCode.GDselector_95btnObjects1 */
/* Reuse gdjs.GameSceneCode.GDshop_95slotObjects1 */

gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDshop_9595slotObjects1Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDselector_95btnObjects1.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDselector_95btnObjects1[i].isCurrentAnimationName("selected") ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDselector_95btnObjects1[k] = gdjs.GameSceneCode.GDselector_95btnObjects1[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDselector_95btnObjects1.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList102(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList104 = function(runtimeScene) {

{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDselector_95btnObjects1, gdjs.GameSceneCode.GDselector_95btnObjects2);

gdjs.copyArray(gdjs.GameSceneCode.GDshop_95slotObjects1, gdjs.GameSceneCode.GDshop_95slotObjects2);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDshop_9595slotObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDselector_95btnObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDselector_95btnObjects2[i].isCurrentAnimationName("highlight") ) {
        gdjs.GameSceneCode.condition1IsTrue_0.val = true;
        gdjs.GameSceneCode.GDselector_95btnObjects2[k] = gdjs.GameSceneCode.GDselector_95btnObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDselector_95btnObjects2.length = k;}}
if (gdjs.GameSceneCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameSceneCode.GDselector_95btnObjects2 */
/* Reuse gdjs.GameSceneCode.GDshop_95slotObjects2 */
gdjs.copyArray(runtimeScene.getObjects("txt_shop_item_desc"), gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2);
gdjs.copyArray(runtimeScene.getObjects("txt_shop_item_title"), gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2);
{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDshop_95slotObjects2[0].getVariables()).get("title"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2[i].setString((gdjs.RuntimeObject.getVariableString(((gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs.GameSceneCode.GDshop_95slotObjects2[0].getVariables()).get("description"))));
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDselector_95btnObjects2.length ;i < len;++i) {
    gdjs.GameSceneCode.GDselector_95btnObjects2[i].setPosition((( gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDshop_95slotObjects2[0].getPointX("")),(( gdjs.GameSceneCode.GDshop_95slotObjects2.length === 0 ) ? 0 :gdjs.GameSceneCode.GDshop_95slotObjects2[0].getPointY("")));
}
}}

}


{



}


{

gdjs.copyArray(gdjs.GameSceneCode.GDselector_95btnObjects1, gdjs.GameSceneCode.GDselector_95btnObjects2);

gdjs.copyArray(gdjs.GameSceneCode.GDshop_95slotObjects1, gdjs.GameSceneCode.GDshop_95slotObjects2);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDshop_9595slotObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDselector_95btnObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDselector_95btnObjects2[i].isCurrentAnimationName("highlight") ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDselector_95btnObjects2[k] = gdjs.GameSceneCode.GDselector_95btnObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDselector_95btnObjects2.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList93(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("buy_btn"), gdjs.GameSceneCode.GDbuy_95btnObjects2);
gdjs.copyArray(gdjs.GameSceneCode.GDselector_95btnObjects1, gdjs.GameSceneCode.GDselector_95btnObjects2);


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
gdjs.GameSceneCode.condition1IsTrue_0.val = false;
gdjs.GameSceneCode.condition2IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameSceneCode.mapOfGDgdjs_46GameSceneCode_46GDbuy_9595btnObjects2Objects, runtimeScene, true, false);
}if ( gdjs.GameSceneCode.condition0IsTrue_0.val ) {
{
gdjs.GameSceneCode.condition1IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if ( gdjs.GameSceneCode.condition1IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameSceneCode.GDselector_95btnObjects2.length;i<l;++i) {
    if ( gdjs.GameSceneCode.GDselector_95btnObjects2[i].isCurrentAnimationName("selected") ) {
        gdjs.GameSceneCode.condition2IsTrue_0.val = true;
        gdjs.GameSceneCode.GDselector_95btnObjects2[k] = gdjs.GameSceneCode.GDselector_95btnObjects2[i];
        ++k;
    }
}
gdjs.GameSceneCode.GDselector_95btnObjects2.length = k;}}
}
if (gdjs.GameSceneCode.condition2IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList101(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.5, "buytime");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameSceneCode.eventsList103(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList105 = function(runtimeScene) {

{


gdjs.GameSceneCode.condition0IsTrue_0.val = false;
{
gdjs.GameSceneCode.condition0IsTrue_0.val = gdjs.evtTools.camera.layerIsVisible(runtimeScene, "SHOP");
}if (gdjs.GameSceneCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("selector_btn"), gdjs.GameSceneCode.GDselector_95btnObjects1);
gdjs.copyArray(runtimeScene.getObjects("shop_slot"), gdjs.GameSceneCode.GDshop_95slotObjects1);
{for(var i = 0, len = gdjs.GameSceneCode.GDshop_95slotObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDshop_95slotObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.GameSceneCode.GDselector_95btnObjects1.length ;i < len;++i) {
    gdjs.GameSceneCode.GDselector_95btnObjects1[i].hide(false);
}
}
{ //Subevents
gdjs.GameSceneCode.eventsList104(runtimeScene);} //End of subevents
}

}


};gdjs.GameSceneCode.eventsList106 = function(runtimeScene) {

{


gdjs.GameSceneCode.eventsList13(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList44(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList45(runtimeScene);
}


{



}


{


gdjs.GameSceneCode.eventsList56(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList62(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList66(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList74(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList79(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList91(runtimeScene);
}


{



}


{


gdjs.GameSceneCode.eventsList92(runtimeScene);
}


{


gdjs.GameSceneCode.eventsList105(runtimeScene);
}


};

gdjs.GameSceneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameSceneCode.GDshop_95slotObjects1.length = 0;
gdjs.GameSceneCode.GDshop_95slotObjects2.length = 0;
gdjs.GameSceneCode.GDshop_95slotObjects3.length = 0;
gdjs.GameSceneCode.GDshop_95slotObjects4.length = 0;
gdjs.GameSceneCode.GDshop_95slotObjects5.length = 0;
gdjs.GameSceneCode.GDshop_95slotObjects6.length = 0;
gdjs.GameSceneCode.GDshop_95slotObjects7.length = 0;
gdjs.GameSceneCode.GDshop_95slotObjects8.length = 0;
gdjs.GameSceneCode.GDinventory_95slotObjects1.length = 0;
gdjs.GameSceneCode.GDinventory_95slotObjects2.length = 0;
gdjs.GameSceneCode.GDinventory_95slotObjects3.length = 0;
gdjs.GameSceneCode.GDinventory_95slotObjects4.length = 0;
gdjs.GameSceneCode.GDinventory_95slotObjects5.length = 0;
gdjs.GameSceneCode.GDinventory_95slotObjects6.length = 0;
gdjs.GameSceneCode.GDinventory_95slotObjects7.length = 0;
gdjs.GameSceneCode.GDinventory_95slotObjects8.length = 0;
gdjs.GameSceneCode.GDinventory_95binObjects1.length = 0;
gdjs.GameSceneCode.GDinventory_95binObjects2.length = 0;
gdjs.GameSceneCode.GDinventory_95binObjects3.length = 0;
gdjs.GameSceneCode.GDinventory_95binObjects4.length = 0;
gdjs.GameSceneCode.GDinventory_95binObjects5.length = 0;
gdjs.GameSceneCode.GDinventory_95binObjects6.length = 0;
gdjs.GameSceneCode.GDinventory_95binObjects7.length = 0;
gdjs.GameSceneCode.GDinventory_95binObjects8.length = 0;
gdjs.GameSceneCode.GDpointer_95dragobjectObjects1.length = 0;
gdjs.GameSceneCode.GDpointer_95dragobjectObjects2.length = 0;
gdjs.GameSceneCode.GDpointer_95dragobjectObjects3.length = 0;
gdjs.GameSceneCode.GDpointer_95dragobjectObjects4.length = 0;
gdjs.GameSceneCode.GDpointer_95dragobjectObjects5.length = 0;
gdjs.GameSceneCode.GDpointer_95dragobjectObjects6.length = 0;
gdjs.GameSceneCode.GDpointer_95dragobjectObjects7.length = 0;
gdjs.GameSceneCode.GDpointer_95dragobjectObjects8.length = 0;
gdjs.GameSceneCode.GDslot_95textObjects1.length = 0;
gdjs.GameSceneCode.GDslot_95textObjects2.length = 0;
gdjs.GameSceneCode.GDslot_95textObjects3.length = 0;
gdjs.GameSceneCode.GDslot_95textObjects4.length = 0;
gdjs.GameSceneCode.GDslot_95textObjects5.length = 0;
gdjs.GameSceneCode.GDslot_95textObjects6.length = 0;
gdjs.GameSceneCode.GDslot_95textObjects7.length = 0;
gdjs.GameSceneCode.GDslot_95textObjects8.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95moneyObjects8.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95descObjects8.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95shop_95item_95titleObjects8.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95descObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95descObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95descObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95descObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95descObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95descObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95descObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95descObjects8.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95titleObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95titleObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95titleObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95titleObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95titleObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95titleObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95titleObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95item_95titleObjects8.length = 0;
gdjs.GameSceneCode.GDtxt_95titleObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95titleObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95titleObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95titleObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95titleObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95titleObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95titleObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95titleObjects8.length = 0;
gdjs.GameSceneCode.GDinventory_95title2Objects1.length = 0;
gdjs.GameSceneCode.GDinventory_95title2Objects2.length = 0;
gdjs.GameSceneCode.GDinventory_95title2Objects3.length = 0;
gdjs.GameSceneCode.GDinventory_95title2Objects4.length = 0;
gdjs.GameSceneCode.GDinventory_95title2Objects5.length = 0;
gdjs.GameSceneCode.GDinventory_95title2Objects6.length = 0;
gdjs.GameSceneCode.GDinventory_95title2Objects7.length = 0;
gdjs.GameSceneCode.GDinventory_95title2Objects8.length = 0;
gdjs.GameSceneCode.GDinventory_95titleObjects1.length = 0;
gdjs.GameSceneCode.GDinventory_95titleObjects2.length = 0;
gdjs.GameSceneCode.GDinventory_95titleObjects3.length = 0;
gdjs.GameSceneCode.GDinventory_95titleObjects4.length = 0;
gdjs.GameSceneCode.GDinventory_95titleObjects5.length = 0;
gdjs.GameSceneCode.GDinventory_95titleObjects6.length = 0;
gdjs.GameSceneCode.GDinventory_95titleObjects7.length = 0;
gdjs.GameSceneCode.GDinventory_95titleObjects8.length = 0;
gdjs.GameSceneCode.GDtxt_95controlsObjects1.length = 0;
gdjs.GameSceneCode.GDtxt_95controlsObjects2.length = 0;
gdjs.GameSceneCode.GDtxt_95controlsObjects3.length = 0;
gdjs.GameSceneCode.GDtxt_95controlsObjects4.length = 0;
gdjs.GameSceneCode.GDtxt_95controlsObjects5.length = 0;
gdjs.GameSceneCode.GDtxt_95controlsObjects6.length = 0;
gdjs.GameSceneCode.GDtxt_95controlsObjects7.length = 0;
gdjs.GameSceneCode.GDtxt_95controlsObjects8.length = 0;
gdjs.GameSceneCode.GDitem_95cardObjects1.length = 0;
gdjs.GameSceneCode.GDitem_95cardObjects2.length = 0;
gdjs.GameSceneCode.GDitem_95cardObjects3.length = 0;
gdjs.GameSceneCode.GDitem_95cardObjects4.length = 0;
gdjs.GameSceneCode.GDitem_95cardObjects5.length = 0;
gdjs.GameSceneCode.GDitem_95cardObjects6.length = 0;
gdjs.GameSceneCode.GDitem_95cardObjects7.length = 0;
gdjs.GameSceneCode.GDitem_95cardObjects8.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95hpObjects1.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95hpObjects2.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95hpObjects3.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95hpObjects4.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95hpObjects5.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95hpObjects6.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95hpObjects7.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95hpObjects8.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95mpObjects1.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95mpObjects2.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95mpObjects3.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95mpObjects4.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95mpObjects5.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95mpObjects6.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95mpObjects7.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95mpObjects8.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95expObjects1.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95expObjects2.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95expObjects3.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95expObjects4.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95expObjects5.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95expObjects6.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95expObjects7.length = 0;
gdjs.GameSceneCode.GDitem_95potion_95expObjects8.length = 0;
gdjs.GameSceneCode.GDitem_95heartObjects1.length = 0;
gdjs.GameSceneCode.GDitem_95heartObjects2.length = 0;
gdjs.GameSceneCode.GDitem_95heartObjects3.length = 0;
gdjs.GameSceneCode.GDitem_95heartObjects4.length = 0;
gdjs.GameSceneCode.GDitem_95heartObjects5.length = 0;
gdjs.GameSceneCode.GDitem_95heartObjects6.length = 0;
gdjs.GameSceneCode.GDitem_95heartObjects7.length = 0;
gdjs.GameSceneCode.GDitem_95heartObjects8.length = 0;
gdjs.GameSceneCode.GDitem_95chickenObjects1.length = 0;
gdjs.GameSceneCode.GDitem_95chickenObjects2.length = 0;
gdjs.GameSceneCode.GDitem_95chickenObjects3.length = 0;
gdjs.GameSceneCode.GDitem_95chickenObjects4.length = 0;
gdjs.GameSceneCode.GDitem_95chickenObjects5.length = 0;
gdjs.GameSceneCode.GDitem_95chickenObjects6.length = 0;
gdjs.GameSceneCode.GDitem_95chickenObjects7.length = 0;
gdjs.GameSceneCode.GDitem_95chickenObjects8.length = 0;
gdjs.GameSceneCode.GDitem_95book_95mpObjects1.length = 0;
gdjs.GameSceneCode.GDitem_95book_95mpObjects2.length = 0;
gdjs.GameSceneCode.GDitem_95book_95mpObjects3.length = 0;
gdjs.GameSceneCode.GDitem_95book_95mpObjects4.length = 0;
gdjs.GameSceneCode.GDitem_95book_95mpObjects5.length = 0;
gdjs.GameSceneCode.GDitem_95book_95mpObjects6.length = 0;
gdjs.GameSceneCode.GDitem_95book_95mpObjects7.length = 0;
gdjs.GameSceneCode.GDitem_95book_95mpObjects8.length = 0;
gdjs.GameSceneCode.GDitem_95book_95hpObjects1.length = 0;
gdjs.GameSceneCode.GDitem_95book_95hpObjects2.length = 0;
gdjs.GameSceneCode.GDitem_95book_95hpObjects3.length = 0;
gdjs.GameSceneCode.GDitem_95book_95hpObjects4.length = 0;
gdjs.GameSceneCode.GDitem_95book_95hpObjects5.length = 0;
gdjs.GameSceneCode.GDitem_95book_95hpObjects6.length = 0;
gdjs.GameSceneCode.GDitem_95book_95hpObjects7.length = 0;
gdjs.GameSceneCode.GDitem_95book_95hpObjects8.length = 0;
gdjs.GameSceneCode.GDitem_95book_95expObjects1.length = 0;
gdjs.GameSceneCode.GDitem_95book_95expObjects2.length = 0;
gdjs.GameSceneCode.GDitem_95book_95expObjects3.length = 0;
gdjs.GameSceneCode.GDitem_95book_95expObjects4.length = 0;
gdjs.GameSceneCode.GDitem_95book_95expObjects5.length = 0;
gdjs.GameSceneCode.GDitem_95book_95expObjects6.length = 0;
gdjs.GameSceneCode.GDitem_95book_95expObjects7.length = 0;
gdjs.GameSceneCode.GDitem_95book_95expObjects8.length = 0;
gdjs.GameSceneCode.GDcursorObjects1.length = 0;
gdjs.GameSceneCode.GDcursorObjects2.length = 0;
gdjs.GameSceneCode.GDcursorObjects3.length = 0;
gdjs.GameSceneCode.GDcursorObjects4.length = 0;
gdjs.GameSceneCode.GDcursorObjects5.length = 0;
gdjs.GameSceneCode.GDcursorObjects6.length = 0;
gdjs.GameSceneCode.GDcursorObjects7.length = 0;
gdjs.GameSceneCode.GDcursorObjects8.length = 0;
gdjs.GameSceneCode.GDobj_95buttonsObjects1.length = 0;
gdjs.GameSceneCode.GDobj_95buttonsObjects2.length = 0;
gdjs.GameSceneCode.GDobj_95buttonsObjects3.length = 0;
gdjs.GameSceneCode.GDobj_95buttonsObjects4.length = 0;
gdjs.GameSceneCode.GDobj_95buttonsObjects5.length = 0;
gdjs.GameSceneCode.GDobj_95buttonsObjects6.length = 0;
gdjs.GameSceneCode.GDobj_95buttonsObjects7.length = 0;
gdjs.GameSceneCode.GDobj_95buttonsObjects8.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects1.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects2.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects3.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects4.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects5.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects6.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects7.length = 0;
gdjs.GameSceneCode.GDobj_95btn_95save_95loadObjects8.length = 0;
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects1.length = 0;
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects2.length = 0;
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects3.length = 0;
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects4.length = 0;
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects5.length = 0;
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects6.length = 0;
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects7.length = 0;
gdjs.GameSceneCode.GDbtn_95click_95for_95collectObjects8.length = 0;
gdjs.GameSceneCode.GDbuy_95btnObjects1.length = 0;
gdjs.GameSceneCode.GDbuy_95btnObjects2.length = 0;
gdjs.GameSceneCode.GDbuy_95btnObjects3.length = 0;
gdjs.GameSceneCode.GDbuy_95btnObjects4.length = 0;
gdjs.GameSceneCode.GDbuy_95btnObjects5.length = 0;
gdjs.GameSceneCode.GDbuy_95btnObjects6.length = 0;
gdjs.GameSceneCode.GDbuy_95btnObjects7.length = 0;
gdjs.GameSceneCode.GDbuy_95btnObjects8.length = 0;
gdjs.GameSceneCode.GDobj_95close_95btnObjects1.length = 0;
gdjs.GameSceneCode.GDobj_95close_95btnObjects2.length = 0;
gdjs.GameSceneCode.GDobj_95close_95btnObjects3.length = 0;
gdjs.GameSceneCode.GDobj_95close_95btnObjects4.length = 0;
gdjs.GameSceneCode.GDobj_95close_95btnObjects5.length = 0;
gdjs.GameSceneCode.GDobj_95close_95btnObjects6.length = 0;
gdjs.GameSceneCode.GDobj_95close_95btnObjects7.length = 0;
gdjs.GameSceneCode.GDobj_95close_95btnObjects8.length = 0;
gdjs.GameSceneCode.GDhud_95panelObjects1.length = 0;
gdjs.GameSceneCode.GDhud_95panelObjects2.length = 0;
gdjs.GameSceneCode.GDhud_95panelObjects3.length = 0;
gdjs.GameSceneCode.GDhud_95panelObjects4.length = 0;
gdjs.GameSceneCode.GDhud_95panelObjects5.length = 0;
gdjs.GameSceneCode.GDhud_95panelObjects6.length = 0;
gdjs.GameSceneCode.GDhud_95panelObjects7.length = 0;
gdjs.GameSceneCode.GDhud_95panelObjects8.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144Objects1.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144Objects2.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144Objects3.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144Objects4.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144Objects5.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144Objects6.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144Objects7.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144Objects8.length = 0;
gdjs.GameSceneCode.GDeffectObjects1.length = 0;
gdjs.GameSceneCode.GDeffectObjects2.length = 0;
gdjs.GameSceneCode.GDeffectObjects3.length = 0;
gdjs.GameSceneCode.GDeffectObjects4.length = 0;
gdjs.GameSceneCode.GDeffectObjects5.length = 0;
gdjs.GameSceneCode.GDeffectObjects6.length = 0;
gdjs.GameSceneCode.GDeffectObjects7.length = 0;
gdjs.GameSceneCode.GDeffectObjects8.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects1.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects2.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects3.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects4.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects5.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects6.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects7.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95144x144Objects8.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95256Objects1.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95256Objects2.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95256Objects3.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95256Objects4.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95256Objects5.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95256Objects6.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95256Objects7.length = 0;
gdjs.GameSceneCode.GDhud_95panel_95256Objects8.length = 0;
gdjs.GameSceneCode.GDcoins_95bgObjects1.length = 0;
gdjs.GameSceneCode.GDcoins_95bgObjects2.length = 0;
gdjs.GameSceneCode.GDcoins_95bgObjects3.length = 0;
gdjs.GameSceneCode.GDcoins_95bgObjects4.length = 0;
gdjs.GameSceneCode.GDcoins_95bgObjects5.length = 0;
gdjs.GameSceneCode.GDcoins_95bgObjects6.length = 0;
gdjs.GameSceneCode.GDcoins_95bgObjects7.length = 0;
gdjs.GameSceneCode.GDcoins_95bgObjects8.length = 0;
gdjs.GameSceneCode.GDcoinObjects1.length = 0;
gdjs.GameSceneCode.GDcoinObjects2.length = 0;
gdjs.GameSceneCode.GDcoinObjects3.length = 0;
gdjs.GameSceneCode.GDcoinObjects4.length = 0;
gdjs.GameSceneCode.GDcoinObjects5.length = 0;
gdjs.GameSceneCode.GDcoinObjects6.length = 0;
gdjs.GameSceneCode.GDcoinObjects7.length = 0;
gdjs.GameSceneCode.GDcoinObjects8.length = 0;
gdjs.GameSceneCode.GDselector_95btnObjects1.length = 0;
gdjs.GameSceneCode.GDselector_95btnObjects2.length = 0;
gdjs.GameSceneCode.GDselector_95btnObjects3.length = 0;
gdjs.GameSceneCode.GDselector_95btnObjects4.length = 0;
gdjs.GameSceneCode.GDselector_95btnObjects5.length = 0;
gdjs.GameSceneCode.GDselector_95btnObjects6.length = 0;
gdjs.GameSceneCode.GDselector_95btnObjects7.length = 0;
gdjs.GameSceneCode.GDselector_95btnObjects8.length = 0;
gdjs.GameSceneCode.GDcontrols_95bgObjects1.length = 0;
gdjs.GameSceneCode.GDcontrols_95bgObjects2.length = 0;
gdjs.GameSceneCode.GDcontrols_95bgObjects3.length = 0;
gdjs.GameSceneCode.GDcontrols_95bgObjects4.length = 0;
gdjs.GameSceneCode.GDcontrols_95bgObjects5.length = 0;
gdjs.GameSceneCode.GDcontrols_95bgObjects6.length = 0;
gdjs.GameSceneCode.GDcontrols_95bgObjects7.length = 0;
gdjs.GameSceneCode.GDcontrols_95bgObjects8.length = 0;

gdjs.GameSceneCode.eventsList106(runtimeScene);
return;

}

gdjs['GameSceneCode'] = gdjs.GameSceneCode;
